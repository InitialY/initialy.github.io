import os
from collections import namedtuple
from typing import List, Tuple

Rectangle = namedtuple('Rectangle', ['x1', 'y1', 'x2', 'y2'])


def get_all_file_paths_of_dir(dir_path: str, file_extensions: Tuple[str] = ('.jpg', '.jpeg', '.png')) -> List[str]:
    """
    Iterates through a given directory and it's subdirectories and creates a list of file paths of given file extensions.
    Returns an empty list if there are no valid files. Use create_dir_path function to create a proper directory parameter.
    :param dir_path: directory path containing desired files.
    :param file_extensions: tuple of file extension strings.
    :return: list of file paths of given file extensions.
    """
    paths_to_files: List[str] = []

    for subdir, dirs, files in os.walk(dir_path):
        for file in files:
            file_path = os.path.join(subdir, file)

            if file_path.endswith(file_extensions):
                paths_to_files.append(file_path)

    return paths_to_files


def validate_region_of_image(image_rect: Rectangle, region_of_image_rect: Rectangle) -> bool:
    """
    Check if a given region_of_image_rect lies in image_rect.
    :param image_rect: image boundaries
    :param region_of_image_rect: smaller portion of an image
    """
    return image_rect.x1 < region_of_image_rect.x1 < region_of_image_rect.x2 < image_rect.x2 and \
        image_rect.y1 < region_of_image_rect.y1 < region_of_image_rect.y2 < image_rect.y2
