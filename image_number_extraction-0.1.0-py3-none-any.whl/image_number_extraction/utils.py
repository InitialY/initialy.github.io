import os
from collections import namedtuple
from typing import List, Tuple

Rectangle = namedtuple('Rectangle', ['x1', 'y1', 'x2', 'y2'])


def get_all_file_paths_of_dir(dir_path: str, file_extensions: Tuple[str] = ('.jpg', '.jpeg', '.png')) -> List[str]:
    """
    Iterates through a given directory and it's subdirectories and creates a list of file paths of given file extensions.
    Returns an empty list if there are no valid files. Use create_path function to create a proper directory parameter.
    :param dir_path: directory path containing desired files.
    :param file_extensions: tuple of file extension strings.
    :return: list of file paths of given file extensions.
    """
    paths_to_files: List[str] = []

    for subdir, dirs, files in os.walk(dir_path):
        for file in files:
            file_path = os.path.join(subdir, file)

            if file_path.endswith(file_extensions):
                paths_to_files.append(file_path)

    return paths_to_files


def contains_pkl_files(directory):
    return any(filename.endswith('.pkl') for filename in os.listdir(directory))


def create_dir_path(*subdirectories: str) -> str:
    """
    creates a path of the given directory/folder names with the correct OS separator.
    throws NotADirectoryError if the path is not correct.
    Make sure the parameter order is correct!
    """
    path = os.path.join(*subdirectories)
    if not os.path.isdir(path):
        raise NotADirectoryError(f"The path '{path}' is not a directory.")

    return path


def get_dir_path_separator() -> str:
    return os.sep


def get_current_dir() -> str:
    return os.path.dirname(__file__)


def get_parent_of_current_dir(current_dir: str) -> str:
    return os.path.dirname(current_dir)


def substring_after_last_char(s: str, char: str) -> str:
    index = s.rfind(char)
    if index != -1:
        return s[index + 1:]
    else:
        return s


def substring_before_char(s: str, char: str = '-') -> str:
    index = s.find(char)
    if index != -1:
        return s[:index]
    else:
        return ""


def get_first_digits(s: str) -> str:
    for index, char in enumerate(s):
        if not char.isdigit():
            break
    else:
        index = len(s)

    return s[:index]


def validate_region_of_image(image_rect: Rectangle, region_of_image_rect: Rectangle) -> bool:
    """
    Check if a given region_of_image_rect lies in image_rect.
    :param image_rect: image boundaries
    :param region_of_image_rect: smaller portion of an image
    """
    return image_rect.x1 < region_of_image_rect.x1 < region_of_image_rect.x2 < image_rect.x2 and \
        image_rect.y1 < region_of_image_rect.y1 < region_of_image_rect.y2 < image_rect.y2


def check_file(file_name: str) -> bool:
    """
    Checks if given file is an exisiting file
    :return: boolean value
    """
    return os.path.exists(file_name)
