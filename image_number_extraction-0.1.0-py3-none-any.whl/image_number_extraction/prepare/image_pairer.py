import logging
import re
from datetime import datetime, timezone, timedelta
from io import BytesIO
from operator import attrgetter
from typing import List, Callable, TypeAlias, Generator

import piexif

from image_number_extraction.extract.extract_config_factory import ExtractConfigFactory
from image_number_extraction.logger import setup_logging
from image_number_extraction.prepare.image_region import ImageRegion
from image_number_extraction.prepare.image_pair import ImagePair
import image_number_extraction.prepare.image_preparer as ipre
import image_number_extraction.prepare.image_processor as ipro
import image_number_extraction.extract.extractor as extractor
from image_number_extraction.prepare.image_structure import ImageStructure, ImageType

from cv2.typing import MatLike

CV2Image: TypeAlias = MatLike | None

logger = setup_logging(__name__)

# time window in which coherent screenshots of one game have to be made.
GAME_TIMESTAMP_DELTA_THRESHOLD: timedelta = timedelta(minutes=1, seconds=25)
# date time format of jpg exif meta data tag 'DateTime'; example: '2025:08:24 04:14:03'
DATETIME_RE = re.compile(r"^\d{4}:\d{2}:\d{2} \d{2}:\d{2}:\d{2}$")


def __timestamp_generator() -> Generator[datetime, None, None]:
    epoch = datetime.fromtimestamp(0, tz=timezone.utc)
    delta = timedelta(minutes=1, seconds=26)
    current_time: datetime = epoch
    while True:
        yield current_time
        current_time = current_time + delta


timestamp_generator = __timestamp_generator()


def __check_meta_data(image_bytestring: bytes) -> datetime:
    image_buffer: BytesIO = BytesIO(image_bytestring)
    data: bytes = image_buffer.getvalue()
    try:
        exif_dict = piexif.load(data)
    except Exception:
        logger.warning(f'Image not be captured with Switch System. Default timestamp.')
        return next(timestamp_generator)

    img_ifd = exif_dict.get("0th", {})

    maker_name = img_ifd.get(piexif.ImageIFD.Make)
    if isinstance(maker_name, bytes):
        try:
            maker_name = maker_name.decode('utf-8', errors='ignore')
        except UnicodeDecodeError:
            maker_name = maker_name.decode('latin-1', errors='ignore')
    if maker_name != 'Nintendo co., ltd':
        logger.warning(f'Image not be captured with Switch System. Default timestamp.')
        return next(timestamp_generator)

    dt = img_ifd.get(piexif.ImageIFD.DateTime)
    if dt is None:
        return next(timestamp_generator)
    if isinstance(dt, bytes):
        try:
            dt = dt.decode('utf-8', errors='ignore')
        except UnicodeDecodeError:
            dt = dt.decode('latin-1', errors='ignore')
    if not DATETIME_RE.match(dt):
        logger.warning(f'Image not be captured with Switch System. Default timestamp.')
        return next(timestamp_generator)
    try:
        dt = datetime.strptime(dt, "%Y:%m:%d %H:%M:%S").replace(tzinfo=timezone.utc)
        return dt
    except ValueError:
        return next(timestamp_generator)


def __create_image_structures(
        image_bytestrings: List[bytes],
        config_factory: ExtractConfigFactory,
        test_modifiers: List[List[Callable]]
) -> List[ImageStructure]:
    image_structures: List[ImageStructure] = []
    for i, image_bytestring in enumerate(image_bytestrings):

        timestamp: datetime = __check_meta_data(image_bytestring)

        cv2_image = ipro.get_image_from_byte_string(image_bytestring)
        image_type: ImageType = ImageType.OTHER
        image_region: CV2Image = ipre.prepare_test_image(cv2_image, test_modifiers[0], ImageRegion.POINTS_REGION)
        if image_region is not None:
            number: int = extractor.extract(image_region, config_factory.get_points_config())
            if number is not None:
                image_type = ImageType.POINTS
        image_region: CV2Image = ipre.prepare_test_image(cv2_image, test_modifiers[1], ImageRegion.DARUMA_REGION)
        if image_region is not None:
            number: int = extractor.extract(image_region, config_factory.get_stats_config())
            if number is not None:
                image_type = ImageType.STATS

        image_structures.append(
            ImageStructure(
                origin_index=i,
                timestamp=timestamp,
                image=cv2_image,
                image_type=image_type
            )
        )
    return sorted(image_structures, key=attrgetter('timestamp'))


def __group_image_structures_by_game(
        image_structure_list: List[ImageStructure]
) -> List[List[ImageStructure]]:
    groups: List[List[ImageStructure]] = []
    if image_structure_list is None:
        return groups

    curr_image_structures: List[ImageStructure] = [image_structure_list[0]]

    for i in range(len(image_structure_list) - 1):
        current = image_structure_list[i]
        next_element = image_structure_list[i + 1]
        delta: timedelta = next_element.timestamp - current.timestamp

        if delta > GAME_TIMESTAMP_DELTA_THRESHOLD:
            groups.append(curr_image_structures)
            curr_image_structures = []
        curr_image_structures.append(next_element)

    if curr_image_structures:
        groups.append(curr_image_structures)

    return groups


def __create_image_pairs(image_structure_groups: List[List[ImageStructure]]) \
        -> List[ImagePair]:
    image_pairs: List[ImagePair] = []
    for i, group in enumerate(image_structure_groups):
        points_image_structures: List[ImageStructure] = [image_structure for image_structure in group if
                                                         image_structure.image_type == ImageType.POINTS]
        stats_image_structures: List[ImageStructure] = [image_structure for image_structure in group if
                                                        image_structure.image_type == ImageType.STATS]

        points_image_structures.sort(key=attrgetter('origin_index'))
        stats_image_structures.sort(key=attrgetter('origin_index'))

        image_pair: ImagePair = ImagePair()
        if points_image_structures:
            image_pair.points = points_image_structures[0].image
            image_pair.timestamp = points_image_structures[0].timestamp
        if stats_image_structures:
            image_pair.stats = stats_image_structures[0].image
            image_pair.timestamp = stats_image_structures[0].timestamp

        image_pairs.append(image_pair)
    return image_pairs


def create_image_pairs(
        image_bytestrings: List[bytes],
        config_factory: ExtractConfigFactory,
        test_modifiers: List[List[Callable]],
        debug: bool = False
) -> List[ImagePair]:
    """
    Filters all non-relevant images, creates and returns a list of ImagePair objects.
    If there is a missing partner, the default is None. Result list can be empty.
    :param image_bytestrings: List of image bytestrings.
    :param test_modifiers: list of modifier function lists from ImageProcessor for the image type check.
    :param config_factory: ExtractConfigFactory object for the image type check.
    :param debug: Use logger of not.
    :return: list of ImagePair objects containing two correct images based on the timestamp.
    """
    global logger
    logger.setLevel(logging.INFO if debug else logging.ERROR)

#    logger.info(f'number of images read: {len(image_bytestrings)}')
    image_structures: List[ImageStructure] = __create_image_structures(
        image_bytestrings, config_factory, test_modifiers
    )
    logger.info(
        f'"points"-images: {len([i for i in image_structures if i.image_type == ImageType.POINTS])}')
    logger.info(
        f'"stats"-images: {len([i for i in image_structures if i.image_type == ImageType.STATS])}')
    logger.info(
        f'"other"-images: {len([i for i in image_structures if i.image_type == ImageType.OTHER])}')
    filtered_image_structures: List[ImageStructure] = [i for i in image_structures if i.image_type != ImageType.OTHER]
    image_structure_groups: List[List[ImageStructure]] = __group_image_structures_by_game(filtered_image_structures)
    image_pairs = __create_image_pairs(image_structure_groups)
    return image_pairs
