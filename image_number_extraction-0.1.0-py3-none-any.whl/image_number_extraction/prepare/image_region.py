from image_number_extraction import utils


class ImageRegion:
    POINTS_REGION = utils.Rectangle(x1=688, y1=153, x2=738, y2=173)
    PLACEMENT_REGION = utils.Rectangle(x1=1122, y1=195, x2=1219, y2=297)
    DARUMA_REGION = utils.Rectangle(x1=916, y1=185, x2=971, y2=219)
    KABUKI_REGION = utils.Rectangle(x1=916, y1=238, x2=971, y2=272)
    IPPON_REGION = utils.Rectangle(x1=916, y1=291, x2=971, y2=326)
    KO_REGION = utils.Rectangle(x1=916, y1=344, x2=971, y2=379)
