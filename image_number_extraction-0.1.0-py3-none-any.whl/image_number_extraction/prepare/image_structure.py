from dataclasses import dataclass, field
from enum import Enum


class ImageType(Enum):
    POINTS = 1
    STATS = 2
    OTHER = 3


@dataclass
class ImageStructure:
    origin_index: int
    file_name: str
    byte_string: bytes
    image_type: ImageType = field(default=None)
    delta: int = field(default=0)
