from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import TypeAlias

from cv2.typing import MatLike

CV2Image: TypeAlias = MatLike | None

class ImageType(Enum):
    POINTS = 1
    STATS = 2
    OTHER = 3


@dataclass
class ImageStructure:
    origin_index: int
    timestamp: datetime
    image: CV2Image
    image_type: ImageType = field(default=None)
