from dataclasses import dataclass


@dataclass
class ImagePair:
    points: None = None
    stats: None = None
