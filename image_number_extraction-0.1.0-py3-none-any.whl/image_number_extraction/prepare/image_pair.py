from dataclasses import dataclass
from typing import TypeAlias

from cv2.typing import MatLike

CV2Image: TypeAlias = MatLike

@dataclass
class ImagePair:
    """
    This class is an intermediate type containing two images read with the opencv library.
    It is used to keep track which images are together as two images at best belongs to one game.
    """
    points: CV2Image = None
    stats: CV2Image = None
