from operator import attrgetter
from typing import List, Callable, TypeAlias, Tuple

from image_number_extraction import utils
from image_number_extraction.extract.extract_config_factory import ExtractConfigFactory
from image_number_extraction.prepare.image_region import ImageRegion
from image_number_extraction.prepare.image_pair import ImagePair
import image_number_extraction.prepare.image_preparer as ipre
import image_number_extraction.extract.extractor as extractor
from image_number_extraction.prepare.image_structure import ImageStructure, ImageType

from cv2.typing import MatLike

CV2Image: TypeAlias = MatLike | None


def __filter_nintendo_game(images_with_names: List[Tuple[str, CV2Image]], nintendo_game_id: str) -> List[
    Tuple[str, CV2Image]]:
    """
    Check and filter images based on file name. This ensures the images are taken from the correct Nintendo game.
    Returning ImageStructure list can be empty.
    Background: images transferred with MicroSD Card have an ID in front of their file name, which is distributed by Nintendo.
    :param images_with_names: list of opencv images and file names.
    :param nintendo_game_id: string value. Official Nintendo unique game identification code.
    :return: list of image paths with the correct nintendo game id.
    """
    filtered_images = [i for i in images_with_names if len(i[0]) > 16]
    filtered_images = [i for i in filtered_images if
                       i[0][16] == '_' or i[0].find(nintendo_game_id) >= 0]
    return filtered_images


def __create_image_structures(
        images_with_names: List[Tuple[str, CV2Image]],
        config_factory: ExtractConfigFactory,
        test_modifiers: List[List[Callable]]
) -> List[ImageStructure]:
    image_structures: List[ImageStructure] = []
    for i, image_tuple in enumerate(images_with_names):
        image_type: ImageType = ImageType.OTHER
        image_region: CV2Image = ipre.prepare_test_image(image_tuple[1], test_modifiers[0], ImageRegion.POINTS_REGION)
        number: int = extractor.extract(image_region, config_factory.get_points_config())
        if number is not None:
            image_type = ImageType.POINTS
        image_region: CV2Image = ipre.prepare_test_image(image_tuple[1], test_modifiers[1], ImageRegion.DARUMA_REGION)
        number: int = extractor.extract(image_region, config_factory.get_stats_config())
        if number is not None:
            image_type = ImageType.STATS
        image_structures.append(
            ImageStructure(origin_index=i, file_name=image_tuple[0], image=image_tuple[1], image_type=image_type)
        )

    for i, (current, next_element) in enumerate(zip(images_with_names, images_with_names[1:])):
        first_timestamp: int = int(utils.get_first_digits(current[0]))
        second_timestamp: int = int(utils.get_first_digits(next_element[0]))
        delta: int = abs(first_timestamp - second_timestamp)
        image_structures[i].delta = delta

    return image_structures


def __group_image_structures_by_game(image_structure_list: List[ImageStructure], timestamp_delta_threshold: int) \
        -> List[List[ImageStructure]]:
    groups: List[List[ImageStructure]] = []
    curr_image_structures: List[ImageStructure] = []
    for image_structure in image_structure_list:
        curr_image_structures.append(image_structure)
        if image_structure.delta > timestamp_delta_threshold:
            groups.append(curr_image_structures)
            curr_image_structures = []

    if curr_image_structures:
        groups.append(curr_image_structures)
    return groups


def __create_image_pairs(image_structure_groups: List[List[ImageStructure]]) -> List[ImagePair]:
    image_pairs: List[ImagePair] = []
    for group in image_structure_groups:
        points_image_structures: List[ImageStructure] = [image_structure for image_structure in group if
                                                         image_structure.image_type == ImageType.POINTS]
        stats_image_structures: List[ImageStructure] = [image_structure for image_structure in group if
                                                        image_structure.image_type == ImageType.STATS]

        points_image_structures.sort(key=attrgetter('origin_index'))
        stats_image_structures.sort(key=attrgetter('origin_index'))

        image_pair: ImagePair = ImagePair()
        if points_image_structures:
            image_pair.points = points_image_structures[0].image
        if stats_image_structures:
            image_pair.stats = stats_image_structures[0].image

        image_pairs.append(image_pair)
    return image_pairs


def create_image_pairs(
        images_with_names: List[Tuple[str, CV2Image]],
        timestamp_delta_threshold: int,
        nintendo_game_id: str,
        config_factory: ExtractConfigFactory,
        test_modifiers: List[List[Callable]],
) -> List[ImagePair]:
    """
    Filters all non-relevant images, creates and returns a list of ImagePair objects.
    If there is a missing partner, the default is None. Result list can be empty.
    :param images_with_names: List of opencv images and file names.
    :param test_modifiers: list of modifier function lists from ImageProcessor for the image type check.
    :param config_factory: ExtractConfigFactory object for the image type check.
    :param nintendo_game_id: Official Nintendo unique game identification string.
    :param timestamp_delta_threshold: int value, to define the time window in which coherent screenshots have to be made.
    :return: list of ImagePair objects containing two correct images based on the timestamp.
    """
    filtered_images_with_names: List[Tuple[str, CV2Image]] = __filter_nintendo_game(images_with_names, nintendo_game_id)
    image_structures: List[ImageStructure] = __create_image_structures(
        filtered_images_with_names, config_factory, test_modifiers
    )
    filtered_image_structures: List[ImageStructure] = [i for i in image_structures if i.image_type != ImageType.OTHER]
    image_structure_groups: List[List[ImageStructure]] = __group_image_structures_by_game(
        filtered_image_structures, timestamp_delta_threshold
    )
    image_pairs: List[ImagePair] = __create_image_pairs(image_structure_groups)
    return image_pairs
