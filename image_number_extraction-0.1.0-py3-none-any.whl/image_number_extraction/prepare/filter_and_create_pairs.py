from enum import Enum
from typing import List, Tuple, Callable

from image_number_extraction import utils
from image_number_extraction.prepare.image_region import ImageRegion
from image_number_extraction.prepare.image_pair import ImagePair
from image_number_extraction.prepare.image_preparer import ImagePreparer
from image_number_extraction.prepare.image_processor import ImageProcessor
from image_number_extraction.extract.extractor import Extractor


class ImageType(Enum):
    POINTS = 1
    STATS = 2
    OTHER = 3


class FilterAndCreatePairs:
    @staticmethod
    def _filter_game_id(tournament_dir: str, game_id: str) -> List[str]:
        """
        Retrieves all .jpg and .png images of given tournament_dir containing the given game id in the name.
        Image list can be empty.
        :param tournament_dir: path to images.
        :param game_id: string value. Unique game identification code.
        :return: list of image paths with the correct game id.
        """
        image_dirs: List[str] = utils.get_all_file_paths_of_dir(tournament_dir)
        if len(image_dirs) == 0:
            raise ValueError('The directory should contain .jpg or .png files.')
        filtered_image_dirs: List[str] = []
        for image_dir in image_dirs:
            current_game_id_and_extension = utils.substring_after_last_char(image_dir, '-')
            current_game_id = utils.substring_before_char(current_game_id_and_extension, '.')
            if current_game_id == game_id:
                filtered_image_dirs.append(image_dir)
        if len(filtered_image_dirs) == 0:
            raise ValueError(
                'The provided images either do not have proper naming or are from the wrong game. The name should look like this: 2023070419244500-77C5FCCC39A7B80BD3CF2C480CEBE83C.jpg'
            )
        return filtered_image_dirs

    @staticmethod
    def _filter_doubles_prep(image_dirs: List[str], config_factory, test_modifiers) \
            -> List[Tuple[int, ImageType, int]]:
        preplist = []
        for i, image_dir in enumerate(image_dirs):
            image_type = FilterAndCreatePairs._image_type_check(image_dir, config_factory, test_modifiers)
            next_index = min(i + 1, len(image_dirs) - 1)
            delta = FilterAndCreatePairs._get_delta(image_dir, image_dirs[next_index])
            preplist.append((i, image_type, delta))
        return preplist

    @staticmethod
    def _image_type_check(
            image_path: str, config_factory, test_modifiers: List[List[Callable]]
    ) -> ImageType:
        # empty extraction
        image_region = ImagePreparer.prepare_test_image(image_path, test_modifiers[0], ImageRegion.POINTS_REGION)
        number = Extractor.extract(image_region, config_factory.get_points_config())
        if number is not None:
            return ImageType.POINTS
        image_region = ImagePreparer.prepare_test_image(image_path, test_modifiers[1], ImageRegion.DARUMA_REGION)
        number = Extractor.extract(image_region, config_factory.get_stats_config())
        if number is not None:
            return ImageType.STATS
        else:
            return ImageType.OTHER

    @staticmethod
    def _get_delta(first_image_path: str, second_image_path: str) -> int:
        first_timestamp: int = FilterAndCreatePairs._get_timestamp(first_image_path)
        second_timestamp: int = FilterAndCreatePairs._get_timestamp(second_image_path)
        delta: int = abs(first_timestamp - second_timestamp)
        return delta

    @staticmethod
    def _get_timestamp(image_file_dir: str) -> int:
        filename = utils.substring_after_last_char(image_file_dir, utils.get_dir_path_separator())
        timestamp = utils.substring_before_char(filename, '-')
        return int(timestamp)

    @staticmethod
    def _retrieve_pairs(preplist: List[Tuple[int, ImageType, int]], delta_threshold: int) \
            -> List[Tuple[int, ImageType, int]]:
        pairs = []
        for i in range(len(preplist) - 1):
            if preplist[i][2] <= delta_threshold and preplist[i][1] != preplist[i + 1][1]:
                pairs.extend([preplist[i], preplist[i + 1]])
        return pairs

    @staticmethod
    def _retrieve_singles(preplist: List[Tuple[int, ImageType, int]], delta_threshold: int) \
            -> List[Tuple[int, ImageType, int]]:
        singles = []
        for item in preplist:
            if item[2] >= delta_threshold:
                singles.append(item)
        return singles

    @staticmethod
    def _filter_image_type(preplist: List[Tuple[int, ImageType, int]], image_type: ImageType):
        return [element for element in preplist if element[1] != image_type]

    @staticmethod
    def _create_image_pairs(
            image_dirs: List[str], timestamp_delta_threshold: int, config_factory, test_modifiers
    ) -> List[ImagePair]:
        preplist = FilterAndCreatePairs._filter_doubles_prep(image_dirs, config_factory, test_modifiers)
        filtered_preplist = FilterAndCreatePairs._filter_image_type(preplist, ImageType.OTHER)
        pairs = FilterAndCreatePairs._retrieve_pairs(filtered_preplist, timestamp_delta_threshold)
        sorted_pairs = sorted(pairs)  # sort, to have the correct order of image_type points and stats
        singles_candidates = FilterAndCreatePairs._retrieve_singles(filtered_preplist, timestamp_delta_threshold)
        singles = list(set(singles_candidates) - set(sorted_pairs))
        image_pairs_with_index: List[Tuple[int, ImagePair]] = []
        for i in range(0, len(sorted_pairs), 2):
            image_pairs_with_index.append((
                sorted_pairs[i][0],
                ImagePair(
                    points=ImageProcessor.get_image_of_path(image_dirs[sorted_pairs[i][0]]),
                    stats=ImageProcessor.get_image_of_path(image_dirs[sorted_pairs[i + 1][0]]))
            ))
        for single in singles:
            image_pair = None
            if single[1] == ImageType.POINTS:
                image_pair = ImagePair(points=ImageProcessor.get_image_of_path(image_dirs[single[0]]))
            elif single[1] == ImageType.STATS:
                image_pair = ImagePair(stats=ImageProcessor.get_image_of_path(image_dirs[single[0]]))
            image_pairs_with_index.append((single[0], image_pair))
        image_pairs_with_index.sort()  # merge pairs and singles together based on the original index
        image_path_pairs = [pair for _, pair in image_pairs_with_index]  # cut off the index
        return image_path_pairs

    @staticmethod
    def filter_and_create_pairs(tournament_dir: str, timestamp_delta_threshold: int,
                                game_id: str, config_factory, test_modifiers) \
            -> List[ImagePair]:
        """
        Filters all non-relevant image paths of the tournament dir and creates path pairs of first and second screenshots.
        The result is stored in a list of ImagePair objects. If there is a missing partner, the default is None.
        Result list can be empty.
        :param test_modifiers: list of modifier function lists from ImageProcessor for the image type check.
        :param config_factory: ExtractConfigFactory object for the image type check.
        :param tournament_dir: path to tournament dir created with utils.create_dir_path() method.
        :param timestamp_delta_threshold: int value, to define the time window in which coherent screenshots have to be made.
        :param game_id: string value. Unique game identification code.
        :return: list of ImagePair objects containing two correct image paths based on the timestamp.
        """
        # _filter_game_id(): either not supported image file or not accepted file name or wrong game
        filtered_images_dirs: List[str] = FilterAndCreatePairs._filter_game_id(tournament_dir, game_id)
        # _create_image_pairs(): empty images
        image_pairs: List[ImagePair] = FilterAndCreatePairs._create_image_pairs(
            filtered_images_dirs, timestamp_delta_threshold, config_factory, test_modifiers
        )
        if len(image_pairs) == 0:
            raise ValueError('Something went wrong reading the images.')
        return image_pairs
