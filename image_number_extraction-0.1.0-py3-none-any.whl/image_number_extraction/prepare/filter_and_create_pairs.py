from dataclasses import dataclass, field
from enum import Enum
from operator import attrgetter
from typing import List, Tuple, Callable

from image_number_extraction import utils
from image_number_extraction.prepare.image_region import ImageRegion
from image_number_extraction.prepare.image_pair import ImagePair
import image_number_extraction.prepare.image_preparer as ipre
import image_number_extraction.prepare.image_processor as ipro
import image_number_extraction.extract.extractor as extractor


class ImageType(Enum):
    POINTS = 1
    STATS = 2
    OTHER = 3


@dataclass
class ImageStructure:
    origin_index: int
    filename: str
    bytestring: bytes
    image_type: ImageType = field(default=None)
    delta: int = field(default=0)


def __filter_game(image_structure_list: List[ImageStructure], game_id: str) -> List[ImageStructure]:
    """
    check and filter images according their file name. ImageStructure list can be empty.
    :param image_structure_list: list of ImageStructure objects.
    :param game_id: string value. Unique game identification code.
    :return: list of image paths with the correct game id.
    """
    filter_image_structure_list = [i for i in image_structure_list if len(i.filename) > 16]
    filter_image_structure_list = [i for i in filter_image_structure_list if
                                   i.filename[16] == '_' or i.filename.find(game_id) >= 0]
    return filter_image_structure_list


def __add_image_type(image_structure_list: List[ImageStructure], config_factory, test_modifiers):
    for image_structure in image_structure_list:
        image_structure.image_type = __image_type_check(image_structure.bytestring, config_factory, test_modifiers)


def __image_type_check(
        image_bytestring: bytes, config_factory, test_modifiers: List[List[Callable]]
) -> ImageType:
    # empty extraction
    image_region = ipre.prepare_test_image(image_bytestring, test_modifiers[0], ImageRegion.POINTS_REGION)
    number = extractor.extract(image_region, config_factory.get_points_config())
    if number is not None:
        return ImageType.POINTS
    image_region = ipre.prepare_test_image(image_bytestring, test_modifiers[1], ImageRegion.DARUMA_REGION)
    number = extractor.extract(image_region, config_factory.get_stats_config())
    if number is not None:
        return ImageType.STATS
    else:
        return ImageType.OTHER


def __add_deltas(image_structure_list: List[ImageStructure]):
    for current, next_element in zip(image_structure_list, image_structure_list[1:]):
        current.delta = __get_delta(current.filename, next_element.filename)


def __get_delta(first_filename: str, second_filename: str) -> int:
    first_timestamp: int = __get_timestamp(first_filename)
    second_timestamp: int = __get_timestamp(second_filename)
    delta: int = abs(first_timestamp - second_timestamp)
    return delta


def __get_timestamp(filename: str) -> int:
    timestamp = utils.get_first_digits(filename)
    return int(timestamp)


def __slice_image_structure_list(image_structure_list: List[ImageStructure], timestamp_delta_threshold: int) \
        -> List[List[ImageStructure]]:
    match_imgs_list = []
    curr_match_imgs = []
    for image_structure in image_structure_list:
        curr_match_imgs.append(image_structure)
        if image_structure.delta > timestamp_delta_threshold:
            match_imgs_list.append(curr_match_imgs)
            curr_match_imgs = []
    if curr_match_imgs:
        match_imgs_list.append(curr_match_imgs)
    return match_imgs_list


def __create_image_pairs(match_imgs_list: List[List[ImageStructure]]) -> List[ImagePair]:
    image_pairs: List[ImagePair] = []
    for match_imgs in match_imgs_list:
        points_match_imgs = [match_img for match_img in match_imgs if match_img.image_type == ImageType.POINTS]
        stats_match_imgs = [match_img for match_img in match_imgs if match_img.image_type == ImageType.STATS]

        points_match_imgs.sort(key=attrgetter('origin_index'))
        stats_match_imgs.sort(key=attrgetter('origin_index'))

        image_pair: ImagePair() = ImagePair()
        if len(points_match_imgs) > 0:
            image_pair.points = ipro.get_image_from_bytestring(points_match_imgs[0].bytestring)
        if len(stats_match_imgs) > 0:
            image_pair.stats = ipro.get_image_from_bytestring(stats_match_imgs[0].bytestring)

        image_pairs.append(image_pair)
    return image_pairs


def create_image_pairs(
        image_bytestring_list: List[Tuple[int, str, bytes]],
        timestamp_delta_threshold: int,
        game_id: str,
        config_factory,
        test_modifiers
) -> List[ImagePair]:
    """
    Filters all non-relevant images, creates and returns a list of ImagePair objects.
    If there is a missing partner, the default is None. Result list can be empty.
    :param test_modifiers: list of modifier function lists from ImageProcessor for the image type check.
    :param config_factory: ExtractConfigFactory object for the image type check.
    :param game_id: game identification string.
    :param timestamp_delta_threshold: int value, to define the time window in which coherent screenshots have to be made.
    :param image_bytestring_list: list of image streams. Contains index, file name and bytestring.
    :return: list of ImagePair objects containing two correct images based on the timestamp.
    """
    image_structure_list: List[ImageStructure] = []
    for index, filename, bytestring in image_bytestring_list:
        image_structure_list.append(ImageStructure(index, filename, bytestring))
    filter_image_structure_list = __filter_game(image_structure_list, game_id)
    __add_image_type(filter_image_structure_list, config_factory, test_modifiers)
    filter_image_structure_list = [i for i in filter_image_structure_list if i.image_type != ImageType.OTHER]
    __add_deltas(filter_image_structure_list)
    sliced_filter_image_structure_list: List[List[ImageStructure]] = __slice_image_structure_list(
        filter_image_structure_list, timestamp_delta_threshold
    )
    image_pairs: List[ImagePair] = __create_image_pairs(sliced_filter_image_structure_list)

    return image_pairs
