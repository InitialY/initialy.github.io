from typing import List, Callable, TypeAlias

from image_number_extraction import utils
from image_number_extraction.prepare.image_pair import ImagePair
import image_number_extraction.prepare.image_processor as ipro
from image_number_extraction.prepare.image_region import ImageRegion
from image_number_extraction.extract.game_image_region import GameImageRegion

from cv2.typing import MatLike

CV2Image: TypeAlias = MatLike | None


def prepare_test_image(test_image: CV2Image, test_modifiers: List[Callable], test_region: utils.Rectangle):
    modified_test_image: CV2Image = ipro.modify_image(test_image, test_modifiers)
    test_image_region: CV2Image = ipro.get_region_of_image(modified_test_image, test_region)
    return test_image_region


def create_game_image_regions(image_pairs: List[ImagePair], points_modifiers: List[Callable], stats_modifiers: List[Callable]) \
        -> List[GameImageRegion]:
    """
    Modifies images in ImagePair list and stores regions in a newly created list of CreateGame objects.
    :param image_pairs: list of ImagePair objects.
    :param points_modifiers: list of modifier functions for images of ImageType points.
    :param stats_modifiers: list of modifier functions for images of ImageType stats.
    :return: list of CreateGame objects.
    """
    game_image_region_list: List[GameImageRegion] = []
    for image_pair in image_pairs:
        if image_pair is None:
            continue
        gir = GameImageRegion()
        gir.points = image_pair.points
        gir.stats = image_pair.stats
        if gir.points is not None:
            modified_points = ipro.modify_image(gir.points, points_modifiers)
            gir.points_region = ipro.get_region_of_image(modified_points, ImageRegion.POINTS_REGION)
            gir.placement_region = ipro.get_region_of_image(modified_points, ImageRegion.PLACEMENT_REGION)
            gir.placement_color_region = ipro.get_region_of_image(gir.points, ImageRegion.PLACEMENT_COLOR_REGION)
        if gir.stats is not None:
            modified_stats = ipro.modify_image(gir.stats, stats_modifiers)
            gir.daruma_region = ipro.get_region_of_image(modified_stats, ImageRegion.DARUMA_REGION)
            gir.kabuki_region = ipro.get_region_of_image(modified_stats, ImageRegion.KABUKI_REGION)
            gir.ippon_region = ipro.get_region_of_image(modified_stats, ImageRegion.IPPON_REGION)
            gir.ko_region = ipro.get_region_of_image(modified_stats, ImageRegion.KO_REGION)
        game_image_region_list.append(gir)
    return game_image_region_list
