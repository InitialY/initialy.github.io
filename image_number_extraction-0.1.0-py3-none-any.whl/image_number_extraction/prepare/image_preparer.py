from typing import List, Callable

from image_number_extraction import utils
from image_number_extraction.prepare.image_pair import ImagePair
import image_number_extraction.prepare.image_processor as ipro
from image_number_extraction.prepare.image_region import ImageRegion
from image_number_extraction.extract.create_game import CreateGame


def prepare_test_image(test_image_bytestring: bytes, test_modifiers: List[Callable], test_region: utils.Rectangle):
    test_image = ipro.get_image_from_byte_string(test_image_bytestring)
    modified_test_image = ipro.modify_image(test_image, test_modifiers)
    test_image_region = ipro.get_region_of_image(modified_test_image, test_region)
    return test_image_region


def prepare_images(image_pairs: List[ImagePair], points_modifiers: List[Callable], stats_modifiers: List[Callable]) \
        -> List[CreateGame]:
    """
    Modifies images in ImagePair list and stores regions in a newly created list of CreateGame objects.
    :param image_pairs: list of ImagePair objects.
    :param points_modifiers: list of modifier functions for images of ImageType points.
    :param stats_modifiers: list of modifier functions for images of ImageType stats.
    :return: list of CreateGame objects.
    """
    create_game_list: List[CreateGame] = []
    for image_pair in image_pairs:
        if image_pair is None:
            continue
        cg = CreateGame()
        cg.points = image_pair.points
        cg.stats = image_pair.stats
        if cg.points is not None:
            modified_points = ipro.modify_image(cg.points, points_modifiers)
            cg.points_region = ipro.get_region_of_image(modified_points, ImageRegion.POINTS_REGION)
            cg.placement_region = ipro.get_region_of_image(modified_points, ImageRegion.PLACEMENT_REGION)
        if cg.stats is not None:
            modified_stats = ipro.modify_image(cg.stats, stats_modifiers)
            cg.daruma_region = ipro.get_region_of_image(modified_stats, ImageRegion.DARUMA_REGION)
            cg.kabuki_region = ipro.get_region_of_image(modified_stats, ImageRegion.KABUKI_REGION)
            cg.ippon_region = ipro.get_region_of_image(modified_stats, ImageRegion.IPPON_REGION)
            cg.ko_region = ipro.get_region_of_image(modified_stats, ImageRegion.KO_REGION)
        create_game_list.append(cg)
    return create_game_list
