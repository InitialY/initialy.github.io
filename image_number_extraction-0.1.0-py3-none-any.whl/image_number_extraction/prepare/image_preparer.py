from typing import List, Callable

from image_number_extraction import utils
from image_number_extraction.prepare.image_pair import ImagePair
from image_number_extraction.prepare.image_processor import ImageProcessor
from image_number_extraction.prepare.image_region import ImageRegion
from image_number_extraction.extract.create_game import CreateGame


class ImagePreparer:

    @staticmethod
    def prepare_test_image(test_image_path: str, test_modifiers: List[Callable], test_region: utils.Rectangle):
        test_image = ImageProcessor.get_image_of_path(test_image_path)
        modified_test_image = ImageProcessor.modify_image(test_image, test_modifiers)
        test_image_region = ImageProcessor.get_region_of_image(modified_test_image, test_region)
        return test_image_region

    @staticmethod
    def prepare_images(image_pairs: List[ImagePair], points_modifiers, stats_modifiers) \
            -> List[CreateGame]:
        create_game_list: List[CreateGame] = []
        for image_pair in image_pairs:
            if image_pair is None:
                continue
            cg = CreateGame()
            cg.points = image_pair.points
            cg.stats = image_pair.stats
            if cg.points is not None:
                modified_points = ImageProcessor.modify_image(cg.points, points_modifiers)
                cg.points_region = ImageProcessor.get_region_of_image(modified_points, ImageRegion.POINTS_REGION)
                cg.placement_region = ImageProcessor.get_region_of_image(modified_points, ImageRegion.PLACEMENT_REGION)
            if cg.stats is not None:
                modified_stats = ImageProcessor.modify_image(cg.stats, stats_modifiers)
                cg.daruma_region = ImageProcessor.get_region_of_image(modified_stats, ImageRegion.DARUMA_REGION)
                cg.kabuki_region = ImageProcessor.get_region_of_image(modified_stats, ImageRegion.KABUKI_REGION)
                cg.ippon_region = ImageProcessor.get_region_of_image(modified_stats, ImageRegion.IPPON_REGION)
                cg.ko_region = ImageProcessor.get_region_of_image(modified_stats, ImageRegion.KO_REGION)
            create_game_list.append(cg)
        return create_game_list
