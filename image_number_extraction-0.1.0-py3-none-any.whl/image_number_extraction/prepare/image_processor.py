from typing import List, TypeAlias, Optional, Tuple, Callable

from cv2 import imread, imdecode, IMREAD_COLOR, cvtColor, COLOR_BGR2GRAY, bitwise_not, inRange
from cv2.typing import MatLike
from numpy import array, frombuffer, uint8, ndindex
from image_number_extraction import utils

CV2Image: TypeAlias = MatLike | None


def get_image_of_path(image_path: str) -> CV2Image:
    """
    returns a cv matrix which can be empty if there was an error.
    :param image_path: path to image.
    :return: cv matrix (numpy array)
    """
    image = imread(image_path)
    if image is None or image.size == 0:
        return None
    return image


def get_images_of_paths(image_directory: str) -> List[CV2Image]:
    """
    Creates a list of opencv images out of a given image directory.
    If path is not correct or does not have any images the result is None.
    :param image_directory: directory to images.
    :return: either None or an opencv image.
    """
    paths: List[str] = utils.get_all_file_paths_of_dir(image_directory)
    imgs: List[CV2Image] = [get_image_of_path(path) for path in paths]
    return imgs


def get_image_from_byte_string(byte_string: bytes) -> CV2Image:
    np_arr = frombuffer(byte_string, uint8)
    image_np: CV2Image = imdecode(np_arr, IMREAD_COLOR)
    return image_np


def get_images_from_byte_strings(byte_string_list: List[bytes]) -> List[CV2Image]:
    return [get_image_from_byte_string(byte_string) for byte_string in byte_string_list]


def get_region_of_image(image: CV2Image, region_of_image: utils.Rectangle) -> CV2Image:
    """
    Create and return a region of an opencv image from given path.
    If the path is not right the return is None.
    :param image: opencv image. use get_image_of_path method.
    :param region_of_image: utils.Rectangle for cropping a region.
    """
    if image is None:
        return None

    dimensions = image.shape
    image_rect = utils.Rectangle(x1=0, y1=0, x2=dimensions[1], y2=dimensions[0])
    region_validate: bool = \
        utils.validate_region_of_image(image_rect=image_rect, region_of_image_rect=region_of_image)

    if not region_validate:
        return None

    sliced_image: CV2Image = image[region_of_image.y1:region_of_image.y2, region_of_image.x1:region_of_image.x2]
    image: CV2Image = sliced_image

    return image


def convert_to_grayscale(img_to_convert: CV2Image) -> CV2Image:
    """
    Turns the given OpenCV image into grayscale and returns the resulting image.
    """
    converted_img: CV2Image = cvtColor(img_to_convert, COLOR_BGR2GRAY)
    return converted_img


def invert_colors_of_image(img_to_convert: CV2Image) -> CV2Image:
    """
    Returns the invert of the given OpenCV image.
    """
    converted_img: CV2Image = bitwise_not(img_to_convert)
    return converted_img

def check_color_appearance(
        image: CV2Image, percentage_threshold: float = 0.2
) -> int:
    """
    Check if OpenCV image contains any of the given color to a certain percentage. Returns number of appeared color.
    :param image: cv2 created image
    :param percentage_threshold: min float percentage the color has to appear in given image to be considered a
    color of the image. This excludes the case where a color appears relatively sparsely in the image.
    :return: returns number of appeared color. Returns 0 if none of the colors appear.
    """

    # color list in form of 8 bit BGR (inverted RGB) tuples.
    # The first list in the tuple contains the lower boundary of a color and the second the upper.
    placement_color_boundaries: List[Tuple[List[int], List[int]]] = [
        ([0, 174, 247], [15, 185, 255]),
        ([172, 175, 150], [180, 186, 160]),
        ([89, 134, 174], [98, 148, 182]),
        ([233, 177, 0], [255, 191, 9]),
    ]
    color_num: int = 0
    counter: int = 1
    for (lower, upper) in placement_color_boundaries:
        lower = array(lower, dtype='uint8')
        upper = array(upper, dtype='uint8')
        mask = inRange(image, lower, upper)
        if mask.max() == 255:
            num_pixel: int = 0
            for row, pixel in ndindex(mask.shape):
                if mask[row, pixel] == 255:
                    num_pixel += 1
            if (num_pixel / mask.size) >= percentage_threshold:
                color_num = counter
        counter += 1
    return color_num


def modify_image(image: CV2Image, modifier_function_list: List[Callable]) -> CV2Image:
    """
    creates a copy of given image, modifies it with given modifiers and returns a modified image.
    :param image: OpenCV image.
    :param modifier_function_list: List of ImageProcessor modify methods.
    :return: modified OpenCV image.
    """
    if image is None:
        return image
    modded_img: CV2Image = image.copy()
    for modifier in modifier_function_list:
        modded_img = modifier(modded_img)
    return modded_img
