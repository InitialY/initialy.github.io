from typing import List

import cv2
from image_number_extraction import utils


class ImageProcessor:

    @staticmethod
    def get_image_of_path(image_path: str):
        return cv2.imread(image_path)

    @staticmethod
    def get_images_of_paths(image_directory: str):
        """
        Creates an opencv image out of a given image directory.
        If path is not correct or does not have any images the result is None.
        :param image_directory: directory to images.
        :return: either None or an opencv image.
        """
        paths: List[str] = utils.get_all_file_paths_of_dir(image_directory)
        imgs = [ImageProcessor.get_image_of_path(path) for path in paths]
        return imgs

    @staticmethod
    def get_region_of_image(image, region_of_image):
        """
        Create and return a region of an opencv image from given path.
        If the path is not right the return is None.
        :param image: opencv image. use get_image_of_path method.
        :param region_of_image: utils.Rectangle for cropping a region.
        """
        if image is None:
            return None

        dimensions = image.shape
        image_rect = utils.Rectangle(x1=0, y1=0, x2=dimensions[1], y2=dimensions[0])
        region_validate: bool = \
            utils.validate_region_of_image(image_rect=image_rect, region_of_image_rect=region_of_image)

        if not region_validate:
            return None

        sliced_image = image[region_of_image.y1:region_of_image.y2, region_of_image.x1:region_of_image.x2]
        image = sliced_image

        return image

    @staticmethod
    def convert_to_grayscale(img_to_convert):
        """
        Turns the given OpenCV image into grayscale and returns the resulting image.
        """
        converted_img = cv2.cvtColor(img_to_convert, cv2.COLOR_BGR2GRAY)
        return converted_img

    @staticmethod
    def invert_colors_of_image(img_to_convert):
        """
        Returns the invert of the given OpenCV image.
        """
        converted_img = cv2.bitwise_not(img_to_convert)
        return converted_img

    @staticmethod
    def modify_image(image, modifier_function_list):
        """
        creates a copy of given image, modifies it with given modifiers and returns a modified image.
        :param image: OpenCV image.
        :param modifier_function_list: List of ImageProcessor modify methods.
        :return: modified OpenCV image.
        """
        modded_img = image.copy()
        for modifier in modifier_function_list:
            modded_img = modifier(modded_img)
        return modded_img
