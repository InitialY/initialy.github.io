import logging.config


def setup_logging(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    logging_config = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'simple': {
                'format': '%(name)s - %(levelname)s - %(message)s'
            }
        },
        'handlers': {
            'stdout': {
                'class': 'logging.StreamHandler',
                'formatter': 'simple',
                'stream': 'ext://sys.stdout',
            }
        },
        'loggers': {
            'root': {'level': 'NOTSET', 'handlers': ['stdout']},
        }
    }
    logging.config.dictConfig(logging_config)
    return logger