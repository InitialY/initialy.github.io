import unittest
from typing import List, Tuple

from image_number_extraction.prepare.filter_and_create_pairs import FilterAndCreatePairs
from image_number_extraction.prepare.filter_and_create_pairs import ImageType


class TestFilterAndCreatePairs(unittest.TestCase):
    timestamp_delta_threshold: int = 8500
    test_cases: List[
        Tuple[
            List[Tuple[int, ImageType, int]],
            List[Tuple[int, ImageType, int]],
            List[Tuple[int, ImageType, int]]
        ]
    ] = [([
              (1, ImageType.POINTS, 500),
              (2, ImageType.STATS, 500),
              (3, ImageType.STATS, 500),
              (4, ImageType.POINTS, 500),
              (5, ImageType.STATS, 234000),
              (6, ImageType.POINTS, 500),
              (7, ImageType.STATS, 234000),
              (8, ImageType.STATS, 234000),
              (9, ImageType.STATS, 0),
          ], [
              (8, ImageType.STATS, 234000),
              (9, ImageType.STATS, 0),
          ], [
              (1, ImageType.POINTS, 500),
              (2, ImageType.STATS, 500),
              (6, ImageType.POINTS, 500),
              (7, ImageType.STATS, 234000),
          ]
    ),
        ([], [], []),
        ([(1, ImageType.POINTS, 0)], [(1, ImageType.POINTS, 0)], []),
        ([(1, ImageType.POINTS, 500), (2, ImageType.POINTS, 0)], [(1, ImageType.POINTS, 500)], []),
        ([(1, ImageType.POINTS, 234000), (2, ImageType.STATS, 0)], [(1, ImageType.POINTS, 234000), (2, ImageType.STATS, 0)], [])
    ]

    def test_create_pairs_and_singles(self):
        for preplist, expected_singles, expected_pairs in self.test_cases:
            with self.subTest(preplist):
                result_singles, result_pairs = FilterAndCreatePairs._create_pairs_and_singles(
                    preplist, self.timestamp_delta_threshold
                )
                self.assertListEqual(result_singles, expected_singles)
                self.assertListEqual(result_pairs, expected_pairs)


if __name__ == '__main__':
    unittest.main()
