import unittest


class TestFilterAndCreatePairs(unittest.TestCase):

    def test_create_pairs_and_singles(self):
        pass


if __name__ == '__main__':
    unittest.main()
