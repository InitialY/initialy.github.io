import argparse
import os
from typing import List, TypeAlias
from tempfile import NamedTemporaryFile

from image_number_extraction import utils

import image_number_extraction.prepare.image_pairer as image_pairer
import image_number_extraction.prepare.image_preparer as ipre
import image_number_extraction.prepare.image_processor as ipro
from image_number_extraction.extract.game_image_region import GameImageRegion

from image_number_extraction.extract.excel_writer import ExcelWriter
from image_number_extraction.extract.game import Game
from image_number_extraction.extract.game_creator import GameCreator
from image_number_extraction.extract.extract_config_factory import ExtractConfigFactory
from image_number_extraction.extract.tournament import Tournament
from image_number_extraction.prepare.image_pair import ImagePair

from cv2.typing import MatLike

CV2Image: TypeAlias = MatLike | None

PARENT_OF_CURR_DIR: str = os.path.dirname(os.path.dirname(__file__))
POINTS_DIGIT_TEMPLATES_DIR: str = f'{PARENT_OF_CURR_DIR}{os.sep}template_images{os.sep}digits_dark'
POINTS_SIGN_TEMPLATES_DIR: str = f'{PARENT_OF_CURR_DIR}{os.sep}template_images{os.sep}digits_dark_sign'
PLACEMENT_DIGIT_TEMPLATES_DIR: str = f'{PARENT_OF_CURR_DIR}{os.sep}template_images{os.sep}digits_placement'
STATS_DIGIT_TEMPLATES_DIR: str = f'{PARENT_OF_CURR_DIR}{os.sep}template_images{os.sep}digits_light'

POINTS_TEMPLATES_MAPPING: List[str] = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
POINTS_SIGN_TEMPLATES_MAPPING: List[str] = ['+1', '-1']
PLACEMENT_TEMPLATES_MAPPING: List[str] = ['5', '6', '7', '8']
STATS_TEMPLATES_MAPPING: List[str] = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

POINTS_MODIFIERS = [ipro.convert_to_grayscale]
PLACEMENT_MODIFIERS = [ipro.convert_to_grayscale]
STATS_MODIFIERS = [ipro.convert_to_grayscale, ipro.invert_colors_of_image]

extract_config_factory = ExtractConfigFactory(
    POINTS_DIGIT_TEMPLATES_DIR, POINTS_SIGN_TEMPLATES_DIR, PLACEMENT_DIGIT_TEMPLATES_DIR, STATS_DIGIT_TEMPLATES_DIR,
    POINTS_TEMPLATES_MAPPING, POINTS_SIGN_TEMPLATES_MAPPING, PLACEMENT_TEMPLATES_MAPPING, STATS_TEMPLATES_MAPPING,
    POINTS_MODIFIERS, PLACEMENT_MODIFIERS, STATS_MODIFIERS
)
gc: GameCreator = GameCreator(extract_config_factory)

test_modifiers = [POINTS_MODIFIERS, STATS_MODIFIERS]


def create_tournament(
        image_bytestrings: List[bytes],
        tournament_name: str, short_name: str, is_team: bool = False, debug: bool = False
) -> Tournament:
    image_pairs: List[ImagePair] = image_pairer.create_image_pairs(
        image_bytestrings=image_bytestrings,
        config_factory=extract_config_factory,
        test_modifiers=test_modifiers,
        debug=debug
    )

    game_image_region_list: List[GameImageRegion] = ipre.create_game_image_regions(
        image_pairs=image_pairs, points_modifiers=POINTS_MODIFIERS, stats_modifiers=STATS_MODIFIERS
    )

    games: List[Game] = [
        gc.create_game(game_image_region_list[index], image_pairs[index].timestamp, is_team)
        for index in range(len(game_image_region_list))
    ]

    tournament: Tournament = Tournament(
        name=tournament_name, short_name=short_name, games=games
    )

    return tournament


def create_tournament_from_stream(
        image_bytestrings: List[bytes],
        tournament_name: str = 'Untitled Tournament',
        is_team: bool = False,
        debug: bool = False
):
    """
    The parameters include a list of dictionaries of the image file names and byte strings, the name of the tournament,
    short name, resulting total points at the end of the tournament, bool flag for the tournament format.
    Make sure to pass bytestrings and filenames instead of the file paths.
    :param image_bytestrings: List of image bytestrings.
    :param tournament_name: the name of the tournament.
    except for an underscore, and it should not start with a digit.
    :param is_team: bool flag for the tournament format.
    :param debug: Use logger of not.
    :return: Tournament object.
    """
    return create_tournament(image_bytestrings, tournament_name, 'tour', is_team, debug)


def create_tournament_from_files(
        tournament_dir: str,
        tournament_name: str,
        short_name: str,
        is_team: bool = False,
        debug: bool = False
) -> Tournament:
    """
    Takes a path to tournament directory which contains match result images and creates a Tournament object.
    :param tournament_dir: path to tournament as string.
    :param tournament_name: the name of the tournament.
    :param short_name: abbreviation of the tournament. Make sure the name does not contain special characters,
    except for an underscore, and it should not start with a digit.
    :param is_team: bool flag for the tournament format.
    :param debug: Use logger of not.
    :return: Tournament object.
    """
    image_bytestrings: List[bytes] = []
    file_paths = utils.get_all_file_paths_of_dir(tournament_dir)
    for file_path in file_paths:
        image_bytestring = open(file_path, 'rb').read()
        image_bytestrings.append(image_bytestring)
    return create_tournament(image_bytestrings, tournament_name, short_name, is_team, debug)


def export_as_excel(tournaments: List[Tournament], excel_file_name: str = 'NinjalaTournamentStats.xlsx') -> None:
    excel_writer = ExcelWriter(excel_file_name)
    for tournament in tournaments:
        excel_writer.add_tournament(tournament)
    excel_writer.close_workbook()


def export_as_excel_stream(
        tournaments: List[Tournament], excel_file_name: str = 'NinjalaTournamentStats.xlsx'
) -> bytes:
    excel_writer = ExcelWriter(excel_file_name)

    for tournament in tournaments:
        excel_writer.add_tournament(tournament)

    with NamedTemporaryFile() as tmp:
        excel_writer.close_workbook_io(tmp)
        tmp.seek(0)
        stream: bytes = tmp.read()
        return stream


def main(tourneys_info, xslx_name):
    tournaments: List[Tournament] = []
    for tournament_info in tourneys_info:
        t = create_tournament_from_files(
            tournament_dir=tournament_info['tournament-dir'],
            tournament_name=tournament_info['name'],
            short_name=tournament_info['short-name'],
            is_team=tournament_info['team'],
            debug=tournament_info['debug']
        )
        print(t.get_summary())
        tournaments.append(t)
    xslx_dir: str = f'{xslx_name}'
    export_as_excel(tournaments, xslx_dir)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description='Extracts statistical values of screenshots and creates an Excel sheet.', prog='StatsCreator'
    )
    tournaments_info = []
    parser.add_argument(
        '-td', '--folder', metavar='TOURNAMENT DIR', action='append', required=True,
        help='Path to the folder containing the tournament match results screenshots'
    )
    parser.add_argument(
        '-n', '--name', action='append',
        help='name of the tournament'
    )
    parser.add_argument(
        '-sn', '--short', metavar='SHORT NAME', action='append',
        help='abbreviation of tournament, used for the excel sheet and table'
    )
    parser.add_argument(
        '--team', action='store_true',
        help='format of the tournament. If it is set, it\'s a team tournament, otherwise it is a solo tournament'
    )
    parser.add_argument(
        '--debug', action='store_true',
        help='Use logger of not.'
    )

    parser.add_argument(
        '-o', '--output', default='NinjalaTournamentStats.xlsx',
        help='output Excel file name. Please add the suffix .xlsx'
    )

    args = parser.parse_args()

    if args.folder:
        for i in range(len(args.folder)):
            tournaments_info.append({
                'tournament-dir': args.folder[i],
                'name': args.name[i] if args.name and i < len(args.name) else None,
                'short-name': args.short[i] if args.short and i < len(args.short) else None,
                'team': args.team if args.team else False,
                'debug': args.debug if args.debug else False,
            })
    main(tournaments_info, args.output)
