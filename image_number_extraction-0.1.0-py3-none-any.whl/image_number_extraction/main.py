import argparse
from typing import List, Tuple
from tempfile import NamedTemporaryFile

from image_number_extraction import utils

import image_number_extraction.prepare.filter_and_create_pairs as fcp
import image_number_extraction.prepare.image_preparer as ipre
import image_number_extraction.prepare.image_processor as ipro

from image_number_extraction.extract.excel_writer import ExcelWriter
from image_number_extraction.extract.game_creator import GameCreator
from image_number_extraction.extract.extract_config_factory import ExtractConfigFactory
from image_number_extraction.extract.tournament import Tournament
from image_number_extraction.prepare.image_structure import ImageStructure


def create_tournament(
        image_structure_list: List[ImageStructure],
        tournament_name: str, short_name: str, total_points: int, is_team: bool = False
):
    # DO CONFIG STUFF
    GAME_ID: str = '77C5FCCC39A7B80BD3CF2C480CEBE83C'
    TIMESTAMP_DELTA_THRESHOLD: int = 8500

    PARENT_OF_CURR_DIR: str = utils.get_parent_of_current_dir(utils.get_current_dir())
    POINTS_DIGIT_TEMPLATES_DIR: str = \
        f'{PARENT_OF_CURR_DIR}{utils.get_dir_path_separator()}template_images{utils.get_dir_path_separator()}digits_dark'
    POINTS_SIGN_TEMPLATES_DIR: str = \
        f'{PARENT_OF_CURR_DIR}{utils.get_dir_path_separator()}template_images{utils.get_dir_path_separator()}digits_dark_sign'
    PLACEMENT_DIGIT_TEMPLATES_DIR: str = \
        f'{PARENT_OF_CURR_DIR}{utils.get_dir_path_separator()}template_images{utils.get_dir_path_separator()}digits_placement'
    STATS_DIGIT_TEMPLATES_DIR: str = \
        f'{PARENT_OF_CURR_DIR}{utils.get_dir_path_separator()}template_images{utils.get_dir_path_separator()}digits_light'

    POINTS_TEMPLATES_MAPPING: List[str] = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    POINTS_SIGN_TEMPLATES_MAPPING: List[str] = ['+1', '-1']
    PLACEMENT_TEMPLATES_MAPPING: List[str] = ['1', '2', '3', '4', '5', '6', '7', '8']
    STATS_TEMPLATES_MAPPING: List[str] = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

    POINTS_MODIFIERS = [ipro.convert_to_grayscale]
    PLACEMENT_MODIFIERS = [ipro.convert_to_grayscale]
    STATS_MODIFIERS = [ipro.convert_to_grayscale, ipro.invert_colors_of_image]

    extract_config_factory = ExtractConfigFactory(
        POINTS_DIGIT_TEMPLATES_DIR, POINTS_SIGN_TEMPLATES_DIR, PLACEMENT_DIGIT_TEMPLATES_DIR, STATS_DIGIT_TEMPLATES_DIR,
        POINTS_TEMPLATES_MAPPING, POINTS_SIGN_TEMPLATES_MAPPING, PLACEMENT_TEMPLATES_MAPPING, STATS_TEMPLATES_MAPPING,
        POINTS_MODIFIERS, PLACEMENT_MODIFIERS, STATS_MODIFIERS
    )

    test_modifiers = [POINTS_MODIFIERS, STATS_MODIFIERS]

    # DO ACTUAL STUFF
    image_pairs = fcp.create_image_pairs(
        image_structure_list=image_structure_list, timestamp_delta_threshold=TIMESTAMP_DELTA_THRESHOLD,
        game_id=GAME_ID, config_factory=extract_config_factory, test_modifiers=test_modifiers
    )

    create_game_list = ipre.prepare_images(
        image_pairs, points_modifiers=POINTS_MODIFIERS, stats_modifiers=STATS_MODIFIERS
    )

    gc = GameCreator(extract_config_factory)
    games = [gc.create_game(create_game, is_team) for create_game in create_game_list]
    tournament = Tournament(name=tournament_name, short_name=short_name, games=games, total_points=total_points)
    return tournament


def create_and_export_single_tournament_as_stream(
        image_structure_list: dict,
        tournament_name: str,
        short_name: str,
        total_points: int = 500,
        is_team: bool = False,
        excel_file_name: str = 'NinjalaTournamentStats.xlsx'
):
    """
    API entry point. Takes parameters for one tournament and returns an Excel file bytestream.
    The parameters include a list of filenames, list of bytestrings of the images, the name of the tournament,
    short name, resulting total points at the end of the tournament, bool flag for the tournament format, and Excel file
    Make sure to pass bytestrings and filenames instead of the file paths.
    :param image_structure_list: list of dictionary. The keys are image_file_name and image_byte_string.
    :param tournament_name: the name of the tournament.
    :param short_name: abbreviation of the tournament. Make sure the name does not contain special characters,
    except for an underscore, and it should not start with a digit.
    :param total_points: integer value, resulting points at the end of the tournament.
    :param is_team: bool flag for the tournament format.
    :param excel_file_name: Excel file name as string ending with .xlsx
    :return: Excel file as byte_string.
    """
    image_structures: List[ImageStructure] = []
    for index, image_structure in enumerate(image_structure_list):
        image_structures.append(
            ImageStructure(index, image_structure['imageFileName'], image_structure['imageByteString'])
        )
    t = create_tournament(image_structures, tournament_name, short_name, total_points, is_team)
    excel_writer = ExcelWriter(excel_file_name)
    excel_writer.add_tournament(t)
    with NamedTemporaryFile() as tmp:
        excel_writer.close_workbook_io(tmp)
        tmp.seek(0)
        stream: bytes = tmp.read()
        return stream


def export_as_excel(tournaments: List[Tournament], excel_file_name: str):
    excel_writer = ExcelWriter(excel_file_name)
    for tournament in tournaments:
        excel_writer.add_tournament(tournament)
    excel_writer.close_workbook()


def create_tournament_from_files(
        tournament_dir: str,
        tournament_name: str,
        short_name: str,
        total_points: int,
        is_team: bool
) -> Tournament:
    """
    Takes a path to tournament directory which contains match result images and creates a Tournament object.
    :param tournament_dir: path to tournament as string.
    :param tournament_name: the name of the tournament.
    :param short_name: abbreviation of the tournament. Make sure the name does not contain special characters,
    except for an underscore, and it should not start with a digit.
    :param total_points: integer value, resulting points at the end of the tournament.
    :param is_team: bool flag for the tournament format.
    :return: Tournament object.
    """
    image_structure_list: List[ImageStructure] = []
    file_paths = utils.get_all_file_paths_of_dir(tournament_dir)
    for index, file_path in enumerate(file_paths):
        with open(file_path, 'rb') as image_file:
            file_name = utils.substring_after_last_char(file_path, utils.get_dir_path_separator())
            byte_string = image_file.read()
            image_structure_list.append(ImageStructure(index, file_name, byte_string))

    return create_tournament(image_structure_list, tournament_name, short_name, total_points, is_team)


def main(tourneys_info, xslx_name):
    tournaments: List[Tournament] = []
    for tournament_info in tourneys_info:
        tournament_dir = tournament_info['tournament-dir']
        tournament_name = tournament_info['name']
        short_name = tournament_info['short-name']
        team = tournament_info['team']
        tournaments.append(
            create_tournament_from_files(
                tournament_dir=tournament_dir,
                tournament_name=tournament_name,
                short_name=short_name,
                total_points=500,
                is_team=team
            )
        )
    xslx_dir: str = f'{xslx_name}'
    export_as_excel(tournaments, xslx_dir)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description='Extracts statistical values of screenshots and creates an Excel sheet.', prog='StatsCreator'
    )
    tournaments_info = []
    parser.add_argument(
        '-td', '--folder', metavar='TOURNAMENT DIR', action='append', required=True,
        help='Path to the folder containing the tournament match results screenshots'
    )
    parser.add_argument(
        '-n', '--name', action='append',
        help='name of the tournament'
    )
    parser.add_argument(
        '-sn', '--short', metavar='SHORT NAME', action='append',
        help='abbreviation of tournament, used for the excel sheet and table'
    )
    parser.add_argument(
        '--team', action='store_true',
        help='format of the tournament. If it is set, it\'s a team tournament, otherwise it is a solo tournament'
    )

    parser.add_argument(
        '-o', '--output', default='NinjalaTournamentStats.xlsx',
        help='output Excel file name. Please add the suffix .xlsx'
    )

    args = parser.parse_args()

    if args.folder:
        for i in range(len(args.folder)):
            tournaments_info.append({
                'tournament-dir': args.folder[i],
                'name': args.name[i] if args.name and i < len(args.name) else None,
                'short-name': args.short[i] if args.short and i < len(args.short) else None,
                'team': args.team if args.team else False
            })
    main(tournaments_info, args.output)
