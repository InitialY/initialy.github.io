from typing import List
from tempfile import NamedTemporaryFile

from image_number_extraction import utils

from image_number_extraction.prepare.filter_and_create_pairs import FilterAndCreatePairs
from image_number_extraction.prepare.image_preparer import ImagePreparer
from image_number_extraction.prepare.image_processor import ImageProcessor

from image_number_extraction.extract.excel_writer import ExcelWriter
from image_number_extraction.extract.game_creator import GameCreator
from image_number_extraction.extract.extract_config_factory import ExtractConfigFactory
from image_number_extraction.extract.tournament import Tournament


def create_tournament(
        tournament_dir: str, tournament_name: str, short_name: str, total_points: int, is_team: bool = False
):
    # DO CONFIG STUFF
    TIMESTAMP_DELTA_THRESHOLD: int = 8500
    GAME_ID: str = '77C5FCCC39A7B80BD3CF2C480CEBE83C'

    PARENT_OF_CURR_DIR: str = utils.get_parent_of_current_dir(utils.get_current_dir())
    POINTS_DIGIT_TEMPLATES_DIR: str = \
        f'{PARENT_OF_CURR_DIR}{utils.get_dir_path_separator()}template_images{utils.get_dir_path_separator()}digits_dark'
    POINTS_SIGN_TEMPLATES_DIR: str = \
        f'{PARENT_OF_CURR_DIR}{utils.get_dir_path_separator()}template_images{utils.get_dir_path_separator()}digits_dark_sign'
    PLACEMENT_DIGIT_TEMPLATES_DIR: str = \
        f'{PARENT_OF_CURR_DIR}{utils.get_dir_path_separator()}template_images{utils.get_dir_path_separator()}digits_placement'
    STATS_DIGIT_TEMPLATES_DIR: str = \
        f'{PARENT_OF_CURR_DIR}{utils.get_dir_path_separator()}template_images{utils.get_dir_path_separator()}digits_light'

    POINTS_TEMPLATES_MAPPING: List[str] = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    POINTS_SIGN_TEMPLATES_MAPPING: List[str] = ['+1', '-1']
    PLACEMENT_TEMPLATES_MAPPING: List[str] = ['1', '2', '3', '4', '5', '6', '7', '8']
    STATS_TEMPLATES_MAPPING: List[str] = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

    POINTS_MODIFIERS = [ImageProcessor.convert_to_grayscale]
    PLACEMENT_MODIFIERS = [ImageProcessor.convert_to_grayscale]
    STATS_MODIFIERS = [ImageProcessor.convert_to_grayscale, ImageProcessor.invert_colors_of_image]

    extract_config_factory = ExtractConfigFactory(
        POINTS_DIGIT_TEMPLATES_DIR, POINTS_SIGN_TEMPLATES_DIR, PLACEMENT_DIGIT_TEMPLATES_DIR, STATS_DIGIT_TEMPLATES_DIR,
        POINTS_TEMPLATES_MAPPING, POINTS_SIGN_TEMPLATES_MAPPING, PLACEMENT_TEMPLATES_MAPPING, STATS_TEMPLATES_MAPPING,
        POINTS_MODIFIERS, PLACEMENT_MODIFIERS, STATS_MODIFIERS
    )

    test_modifiers = [POINTS_MODIFIERS, STATS_MODIFIERS]

    # DO ACTUAL STUFF
    image_pairs = FilterAndCreatePairs.filter_and_create_pairs(
        tournament_dir=tournament_dir, timestamp_delta_threshold=TIMESTAMP_DELTA_THRESHOLD, game_id=GAME_ID,
        config_factory=extract_config_factory, test_modifiers=test_modifiers
    )

    create_game_list = ImagePreparer.prepare_images(
        image_pairs, points_modifiers=POINTS_MODIFIERS, stats_modifiers=STATS_MODIFIERS
    )

    gc = GameCreator(extract_config_factory)
    games = [gc.create_game(create_game, is_team) for create_game in create_game_list]
    tournament = Tournament(name=tournament_name, short_name=short_name, games=games, total_points=total_points)
    return tournament


def create_and_export_single_tournament(
        tournament_dir: str,
        tournament_name: str,
        short_name: str,
        total_points: int = 500,
        is_team: bool = False,
        excel_file_name: str = 'NinjalaTournamentStats.xlsx'
):
    t = create_tournament(tournament_dir, tournament_name, short_name, total_points, is_team)
    excel_writer = ExcelWriter(excel_file_name)
    excel_writer.add_tournament(t)
    with NamedTemporaryFile() as tmp:
        excel_writer.close_workbook_io(tmp)
        tmp.seek(0)
        stream = tmp.read()
        return stream
