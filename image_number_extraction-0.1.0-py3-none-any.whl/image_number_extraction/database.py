import sqlite3
from datetime import datetime, date, timezone
from typing import List

from image_number_extraction.extract.tournament import Tournament

def adapt_datetime_iso(dt: datetime) -> bytes:
    if dt.tzinfo is None:
        dt = dt.astimezone()
    iso = dt.astimezone(timezone.utc).isoformat(timespec="milliseconds")
    return iso.encode("utf-8")


def convert_timestamp_to_iso(b: bytes) -> str:
    return b.decode("utf-8")


sqlite3.register_adapter(datetime, adapt_datetime_iso)
sqlite3.register_converter("TIMESTAMP", convert_timestamp_to_iso)

connection = sqlite3.connect('tournamentstats.db', detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES)

connection.execute("PRAGMA foreign_keys = 1")

cursor = connection.cursor()

cursor.execute('''
CREATE TABLE IF NOT EXISTS tournament (
tournament_id INTEGER PRIMARY KEY AUTOINCREMENT,
tournament_name TEXT NOT NULL,
short_name TEXT NOT NULL,
tournament_format TEXT,
start_time TIMESTAMP,
end_time TIMESTAMP,
starting_points INTEGER,
UNIQUE (tournament_name, short_name)
);
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS game (
    game_id INTEGER PRIMARY KEY AUTOINCREMENT,
    tournament_id INTEGER,
    timestamp TIMESTAMP,
    placement INTEGER,
    gains INTEGER,
    num_daruma INTEGER,
    num_kabuki INTEGER,
    num_ippon INTEGER,
    num_ko INTEGER,
    FOREIGN KEY (tournament_id) REFERENCES tournament(tournament_id) ON DELETE CASCADE
);
''')
connection.commit()


def add_tournament(t: Tournament, tournament_format: str) -> None:
    with connection:
        cursor.execute(
            '''INSERT OR IGNORE INTO tournament (tournament_name, short_name, tournament_format, start_time, end_time, starting_points) VALUES (?,?,?,?,?,?)''',
            (t.name, t.short_name, tournament_format, t.start_time, t.end_time, t.starting_points)
        )
        tournament_id = cursor.lastrowid
        if cursor.rowcount:
            sql: str = '''INSERT INTO game (tournament_id, timestamp, placement, gains, num_daruma, num_kabuki, num_ippon, num_ko) VALUES (?,?,?,?,?,?,?,?)'''
            rows = [
                (tournament_id, game.timestamp, game.placement, game.points, game.num_daruma, game.num_kabuki, game.num_ippon, game.num_ko)
                for game in t.games
            ]
            cursor.executemany(sql, rows)


def get_all_tournaments() -> List[str]:
    cursor.execute('SELECT * FROM tournament;')
    rows = cursor.fetchall()
    for row in rows:
        print(row)
    return rows


def get_all_games() -> List[str]:
    cursor.execute('SELECT * FROM game;')
    rows = cursor.fetchall()
    for row in rows:
        print(row)
    return rows