from typing import List
import openpyxl.utils
from openpyxl.chart import ScatterChart, BarChart, PieChart, Reference
from openpyxl.chart.series_factory import SeriesFactory
from openpyxl.chart.label import DataLabelList
from openpyxl.worksheet.table import Table
from openpyxl.worksheet.formula import ArrayFormula


class ExcelSheet:
    _table_name = ''

    def __init__(self, workbook, worksheet_name: str):
        self._worksheet = self._worksheet = workbook.create_sheet(worksheet_name)

    def add_data(self, data) -> None:
        """
        Write data to Excel File. Data should contain list or tuple elements. None values result into empty cells.
        :return: None. An Excel File will be stored in project path
        """
        for row in data:
            self._worksheet.append(row)

    def create_table(self, table_name: str, min_col: int, max_col: int, min_row: int, max_row: int) -> None:
        min_col_letter = openpyxl.utils.get_column_letter(min_col)
        max_col_letter = openpyxl.utils.get_column_letter(max_col)
        table_range = f"{min_col_letter}{min_row}:{max_col_letter}{max_row}"
        table = Table(displayName=table_name, ref=table_range)
        self._table_name = table_name
        self._worksheet.add_table(table)

    def create_points_chart(self, title: str, max_row: int) -> None:
        scatter_chart = ScatterChart()
        scatter_chart.title = title
        scatter_chart.x_axis.title = 'Game'
        scatter_chart.y_axis.title = 'Points'
        scatter_chart.height = 10  # default is 7.5
        scatter_chart.width = 20  # default is 15
        x_values = Reference(self._worksheet, min_col=1, min_row=2, max_row=max_row)
        y_values = Reference(self._worksheet, min_col=2, min_row=2, max_row=max_row)
        series = SeriesFactory(y_values, x_values, title='Points')
        scatter_chart.series.append(series)
        series.marker.symbol = "circle"
        series.spPr.line.noFill = True
        scatter_chart.y_axis.scaling.min = 500
        scatter_chart.y_axis.scaling.max = 1100
        self._worksheet.add_chart(scatter_chart, 'J3')

    def calculate_current_points_data(self, col: int, min_row: int, max_row: int, gains_header: str):
        if min_row <= 1 or not self._table_name:
            return
        col_letter: str = openpyxl.utils.get_column_letter(col)
        for i in range(min_row, min_row + max_row):
            self._worksheet[f'{col_letter}{i}'] = f'={col_letter}{i - 1}+{self._table_name}[[#This Row],[{gains_header}]]'

    def calculate_aggregated_data(self, col_headers: List[str], min_col: int, min_row: int):
        if not self._table_name:
            return
        aggregate_functions = ['SUM', 'AVERAGE', 'MIN', 'MAX']
        for i, aggregate_function in enumerate(aggregate_functions):
            min_col_letter = openpyxl.utils.get_column_letter(min_col)
            self._worksheet[f'{min_col_letter}{i + min_row}'] = aggregate_function
        min_col += 1
        for j, aggregate_function in enumerate(aggregate_functions):
            for i, header in enumerate(col_headers):
                col_letter = openpyxl.utils.get_column_letter(min_col + i)
                cell_address = f'{col_letter}{min_row + j}'
                cell_function = f'={aggregate_function}({self._table_name}[{header}])'
                self._worksheet[cell_address] = cell_function

    def calculate_sum(self, header: str, dest_row: int, dest_col: int):
        col_letter = openpyxl.utils.get_column_letter(dest_col)
        cell_address = f'{col_letter}{dest_row}'
        cell_function = f'=SUM({self._table_name}[{header}])'
        self._worksheet[cell_address] = cell_function

    def calculate_average(self, header: str, dest_row: int, dest_col: int):
        col_letter = openpyxl.utils.get_column_letter(dest_col)
        cell_address = f'{col_letter}{dest_row}'
        cell_function = f'=ROUND(AVERAGE({self._table_name}[{header}]), 0)'
        self._worksheet[cell_address] = cell_function

    def calculate_min(self, header: str, dest_row: int, dest_col: int):
        col_letter = openpyxl.utils.get_column_letter(dest_col)
        cell_address = f'{col_letter}{dest_row}'
        cell_function = f'=MIN({self._table_name}[{header}])'
        self._worksheet[cell_address] = cell_function

    def calculate_max(self, header: str, dest_row: int, dest_col: int):
        col_letter = openpyxl.utils.get_column_letter(dest_col)
        cell_address = f'{col_letter}{dest_row}'
        cell_function = f'=MAX({self._table_name}[{header}])'
        self._worksheet[cell_address] = cell_function

    def calculate_total_earn(self, col: int, row: int, gains_header: str):
        if not self._table_name:
            return
        col_letter = openpyxl.utils.get_column_letter(col)
        self._worksheet[f'{col_letter}{row}'] = 'TOT EARN'
        next_col_letter = openpyxl.utils.get_column_letter(col + 1)
        self._worksheet[f'{next_col_letter}{row}'] = f'=SUMIF({self._table_name}[{gains_header}], \">0\")'

    def calculate_total_lost(self, col: int, row: int, gains_header: str):
        if not self._table_name:
            return
        col_letter = openpyxl.utils.get_column_letter(col)
        self._worksheet[f'{col_letter}{row}'] = 'TOT LOST'
        next_col_letter = openpyxl.utils.get_column_letter(col + 1)
        self._worksheet[f'{next_col_letter}{row}'] = f'=SUMIF({self._table_name}[{gains_header}], \"<0\")'

    def has_value_in_col(self, col_index: int, min_row: int, max_row: int) -> bool:
        col_letter: str = openpyxl.utils.get_column_letter(col_index)
        for i in range(min_row, max_row):
            if self._worksheet[f'{col_letter}{i}'].value is not None:
                return True
        return False

    def add_placement_frequency_data(self, placement_header: str):
        if not self._table_name:
            return
        caption_columns = [1, 2, 3, 4, 5, 6, 7, 8]
        for i, caption in enumerate(caption_columns):
            self._worksheet.cell(row=i + 24, column=openpyxl.utils.column_index_from_string('J'), value=caption)
        self._worksheet['K23'] = 'Frequency'
        self._worksheet['K24'] = ArrayFormula('K24:K31', f'=FREQUENCY({self._table_name}[{placement_header}],J24:J31)')

    def create_placement_frequency_chart(
            self, c_min_col: int, c_min_row: int, v_min_col: int, v_min_row: int, max_row: int
    ) -> None:
        bar_chart = BarChart()
        bar_chart.title = 'Placement Distribution Frequency'
        bar_chart.x_axis.title = 'Placement'
        bar_chart.y_axis.title = 'Frequency'
        categories = Reference(self._worksheet, min_col=c_min_col, min_row=c_min_row, max_row=max_row)
        values = Reference(self._worksheet, min_col=v_min_col, min_row=v_min_row, max_row=max_row)
        bar_chart.add_data(values, titles_from_data=True)
        bar_chart.set_categories(categories)
        self._worksheet.add_chart(bar_chart, 'M24')

    def add_win_rate_data(self, placement_header: str):
        if not self._table_name:
            return
        caption_columns = ['Win 1-4', 'Lose 5-8']
        for i, caption in enumerate(caption_columns):
            self._worksheet.cell(row=i + 40, column=openpyxl.utils.column_index_from_string('J'), value=caption)
        self._worksheet['K39'] = 'Frequency'
        # self._worksheet['K40'] = f'=SUM(COUNTIF({self._table_name}[placement],J24:J28))'
        self._worksheet['K40'] = \
            f'=COUNTIFS({self._table_name}[{placement_header}], ">=1", {self._table_name}[{placement_header}], "<=4")'
        # self._worksheet['K41'] = f'=SUM(COUNTIF({self._table_name}[placement],J28:J31))'
        self._worksheet['K41'] = \
            f'=COUNTIFS({self._table_name}[{placement_header}], ">=5", {self._table_name}[{placement_header}], "<=8")'

    def add_win_rate_data_team(self, gains_header: str):
        if not self._table_name:
            return
        caption_columns = ['Win', 'Lose']
        for i, caption in enumerate(caption_columns):
            self._worksheet.cell(row=i + 24, column=openpyxl.utils.column_index_from_string('J'), value=caption)
        self._worksheet['K23'] = 'Frequency'
        self._worksheet['K24'] = f'=COUNTIF({self._table_name}[{gains_header}], ">0")'
        self._worksheet['K25'] = f'=COUNTIF({self._table_name}[{gains_header}], "<0")'

    def create_win_rate_chart(
            self, l_min_col: int, l_min_row: int, v_min_col: int, v_min_row: int, max_row: int, dest_cell: str
    ) -> None:
        pie_chart = PieChart()
        pie_chart.title = 'Win Rate'
        labels = Reference(self._worksheet, min_col=l_min_col, min_row=l_min_row, max_row=max_row)
        values = Reference(self._worksheet, min_col=v_min_col, min_row=v_min_row, max_row=max_row)
        pie_chart.add_data(values, titles_from_data=True)
        pie_chart.set_categories(labels)
        pie_chart.dataLabels = DataLabelList()
        pie_chart.dataLabels.showVal = True
        pie_chart.dataLabels.showPercent = True
        self._worksheet.add_chart(pie_chart, dest_cell)
