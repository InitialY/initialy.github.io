from typing import List
import openpyxl.utils
from openpyxl.chart import ScatterChart, BarChart, Reference, DoughnutChart
from openpyxl.chart.label import DataLabelList
from openpyxl.chart.marker import DataPoint
from openpyxl.chart.series_factory import SeriesFactory
from openpyxl.worksheet.table import Table
from openpyxl.worksheet.formula import ArrayFormula


class ExcelSheet:
    _table_name: str = ''

    def __init__(self, workbook, worksheet_name: str):
        self._worksheet = self._worksheet = workbook.create_sheet(worksheet_name)

    def set_width_of_time_col(self):
        self._worksheet.column_dimensions['A'].width = 11

    def add_data(self, data) -> None:
        """
        Write data to Excel File. Data should contain list or tuple elements. None values result into empty cells.
        :return: None. An Excel File will be stored in project path
        """
        for row in data:
            self._worksheet.append(row)

    def convert_to_table(self, table_name: str, min_col: int, max_col: int, min_row: int, max_row: int) -> None:
        min_col_letter = openpyxl.utils.get_column_letter(min_col)
        max_col_letter = openpyxl.utils.get_column_letter(max_col)
        table_range = f"{min_col_letter}{min_row}:{max_col_letter}{max_row}"
        table = Table(displayName=table_name, ref=table_range)
        self._table_name = table_name
        self._worksheet.add_table(table)

    def calculate_current_points_data(self, col: int, min_row: int, max_row: int, gains_header: str):
        if min_row <= 1 or not self._table_name:
            return
        col_letter: str = openpyxl.utils.get_column_letter(col)
        for i in range(min_row, min_row + max_row):
            self._worksheet[f'{col_letter}{i}'] = \
                f'={col_letter}{i - 1}+{self._table_name}[[#This Row],[{gains_header}]]'

    def separate_points_to_color_chart(
            self, pos_col: int, neg_col: int, min_row: int, max_row: int, gains_header: str, points_header: str
    ) -> None:
        pos_col_letter = openpyxl.utils.get_column_letter(pos_col)
        neg_col_letter = openpyxl.utils.get_column_letter(neg_col)
        for i in range(min_row, min_row + max_row):
            self._worksheet[f'{pos_col_letter}{i}'] = \
                (f'=IF({self._table_name}[[#This Row],[{gains_header}]]>=0, '
                 f'{self._table_name}[[#This Row],[{points_header}]], '
                 f'NA())')
            self._worksheet[f'{neg_col_letter}{i}'] = \
                (f'=IF({self._table_name}[[#This Row],[{gains_header}]]<0, '
                 f'{self._table_name}[[#This Row],[{points_header}]], '
                 f'NA())')

    def create_points_chart(
            self, title: str, x_min_col: int, y1_min_col: int, y2_min_col: int, max_row: int,
            tournament_starting_points: int, dest_cell: str
    ) -> None:
        scatter_chart = ScatterChart()
        scatter_chart.title = title
        scatter_chart.x_axis.title = 'Game'
        scatter_chart.y_axis.title = 'Points'
        scatter_chart.height = 10  # default is 7.5
        scatter_chart.width = 20  # default is 15
        scatter_chart.legend = None

        x_values = Reference(self._worksheet, min_col=x_min_col, min_row=2, max_row=max_row)

        y1_values = Reference(self._worksheet, min_col=y1_min_col, min_row=2, max_row=max_row)
        series1 = SeriesFactory(y1_values, x_values, title='Points')
        series1.marker.symbol = 'circle'
        series1.marker.size = 7
        series1.marker.graphicalProperties.solidFill = '80E408'
        series1.marker.graphicalProperties.line.noFill = True
        series1.graphicalProperties.line.noFill = True

        y2_values = Reference(self._worksheet, min_col=y2_min_col, min_row=2, max_row=max_row)
        series2 = SeriesFactory(y2_values, x_values, title='Points')
        series2.marker.symbol = 'circle'
        series2.marker.size = 7
        series2.marker.graphicalProperties.solidFill = 'EC034D'
        series2.marker.graphicalProperties.line.noFill = True
        series2.graphicalProperties.line.noFill = True

        scatter_chart.series.append(series1)
        scatter_chart.series.append(series2)

        scatter_chart.y_axis.scaling.min = tournament_starting_points
        self._worksheet.add_chart(scatter_chart, dest_cell)

    def calculate_aggregated_data(self, col_headers: List[str], min_col: int, min_row: int):
        if not self._table_name:
            return
        aggregate_functions = ['SUM', 'AVERAGE', 'MIN', 'MAX']
        for i, aggregate_function in enumerate(aggregate_functions):
            min_col_letter = openpyxl.utils.get_column_letter(min_col)
            self._worksheet[f'{min_col_letter}{i + min_row}'] = aggregate_function
        min_col += 1
        for j, aggregate_function in enumerate(aggregate_functions):
            for i, header in enumerate(col_headers):
                col_letter = openpyxl.utils.get_column_letter(min_col + i)
                cell_address = f'{col_letter}{min_row + j}'
                cell_function = f'=IFERROR({aggregate_function}({self._table_name}[{header}]), 0)'
                self._worksheet[cell_address] = cell_function

    def calculate_sum(self, header: str, dest_row: int, dest_col: int):
        col_letter = openpyxl.utils.get_column_letter(dest_col)
        cell_address = f'{col_letter}{dest_row}'
        cell_function = f'=SUM({self._table_name}[{header}])'
        self._worksheet[cell_address] = cell_function

    def calculate_average(self, header: str, dest_row: int, dest_col: int):
        col_letter = openpyxl.utils.get_column_letter(dest_col)
        cell_address = f'{col_letter}{dest_row}'
        cell_function = f'=ROUND(AVERAGE({self._table_name}[{header}]), 0)'
        self._worksheet[cell_address] = cell_function

    def calculate_min(self, header: str, dest_row: int, dest_col: int):
        col_letter = openpyxl.utils.get_column_letter(dest_col)
        cell_address = f'{col_letter}{dest_row}'
        cell_function = f'=MIN({self._table_name}[{header}])'
        self._worksheet[cell_address] = cell_function

    def calculate_max(self, header: str, dest_row: int, dest_col: int):
        col_letter = openpyxl.utils.get_column_letter(dest_col)
        cell_address = f'{col_letter}{dest_row}'
        cell_function = f'=MAX({self._table_name}[{header}])'
        self._worksheet[cell_address] = cell_function

    def calculate_total_earn(self, dest_col: int, dest_row: int, gains_header: str):
        if not self._table_name:
            return
        col_letter = openpyxl.utils.get_column_letter(dest_col)
        self._worksheet[f'{col_letter}{dest_row}'] = 'TOT EARN'
        next_col_letter = openpyxl.utils.get_column_letter(dest_col + 1)
        self._worksheet[f'{next_col_letter}{dest_row}'] = f'=SUMIF({self._table_name}[{gains_header}], \">0\")'

    def calculate_total_lost(self, dest_col: int, dest_row: int, gains_header: str):
        if not self._table_name:
            return
        col_letter = openpyxl.utils.get_column_letter(dest_col)
        self._worksheet[f'{col_letter}{dest_row}'] = 'TOT LOST'
        next_col_letter = openpyxl.utils.get_column_letter(dest_col + 1)
        self._worksheet[f'{next_col_letter}{dest_row}'] = f'=SUMIF({self._table_name}[{gains_header}], \"<0\")'

    def has_value_in_col(self, col_index: int, min_row: int, max_row: int) -> bool:
        col_letter: str = openpyxl.utils.get_column_letter(col_index)
        for i in range(min_row, max_row):
            if self._worksheet[f'{col_letter}{i}'].value is not None:
                return True
        return False

    def add_placement_frequency_data(
            self,
            c_min_row: int,
            v_min_row: int,
            c_col: int,
            v_col: int,
            frequency_categories: List[int],
            placement_col_name: str
    ) -> None:
        if not self._table_name:
            return
        for i, category in enumerate(frequency_categories):
            self._worksheet.cell(row=i + c_min_row, column=c_col, value=category)

        c_col_letter: str = openpyxl.utils.get_column_letter(c_col)
        v_col_letter: str = openpyxl.utils.get_column_letter(v_col)
        self._worksheet[f'{v_col_letter}{v_min_row}'] = 'Frequency'
        # for the Excel frequency function, the categories are used to categorize, they are not only used as labels
        self._worksheet[f'{v_col_letter}{v_min_row + 1}'] = ArrayFormula(
            ref=f'{v_col_letter}{v_min_row + 1}:{v_col_letter}{v_min_row + len(frequency_categories)}',
            text=f'=FREQUENCY({self._table_name}[{placement_col_name}],'
                 f'{c_col_letter}{c_min_row}:{c_col_letter}{c_min_row-1 + len(frequency_categories)})'
        )

    def create_placement_frequency_chart(
            self, c_min_col: int, c_min_row: int, v_min_col: int, v_min_row: int, max_row: int, dest_cell: str
    ) -> None:
        bar_chart = BarChart()
        bar_chart.title = 'Placement Distribution Frequency'
        bar_chart.x_axis.title = 'Placement'
        bar_chart.y_axis.title = 'Frequency'
        bar_chart.legend = None

        categories = Reference(self._worksheet, min_col=c_min_col, min_row=c_min_row, max_row=max_row)
        values = Reference(self._worksheet, min_col=v_min_col, min_row=v_min_row, max_row=max_row)
        bar_chart.add_data(values, titles_from_data=True)
        bar_chart.set_categories(categories)
        series = bar_chart.series[0]
        for i in range(4):
            pt = DataPoint(idx=i)
            if pt:
                pt.graphicalProperties.solidFill = '80E408'
                series.dPt.append(pt)
        for i in range(4, 8):
            pt = DataPoint(idx=i)
            if pt:
                pt.graphicalProperties.solidFill = 'EC034D'
                series.dPt.append(pt)

        self._worksheet.add_chart(bar_chart, dest_cell)

    def add_win_rate_data(
            self,
            c_min_row: int,
            v_min_row: int,
            c_col: int,
            v_col: int,
            win_rate_categories: List[str],
            placement_col_name: str
    ) -> None:
        if not self._table_name:
            return
        for i, category in enumerate(win_rate_categories):
            self._worksheet.cell(row=i + c_min_row, column=c_col, value=category)

        value_col_letter = openpyxl.utils.get_column_letter(v_col)
        self._worksheet[f'{value_col_letter}{v_min_row}'] = 'Frequency'
        self._worksheet[f'{value_col_letter}{v_min_row + 1}'] = \
            f'=COUNTIFS({self._table_name}[{placement_col_name}], ">=1", {self._table_name}[{placement_col_name}], "<=4")'
        self._worksheet[f'{value_col_letter}{v_min_row + 2}'] = \
            f'=COUNTIFS({self._table_name}[{placement_col_name}], ">=5", {self._table_name}[{placement_col_name}], "<=8")'

    def add_win_rate_data_team(
            self,
            c_min_row: int,
            v_min_row: int,
            c_col: int,
            v_col: int,
            win_rate_categories: List[str],
            gains_header: str
    ) -> None:
        if not self._table_name:
            return
        for i, category in enumerate(win_rate_categories):
            self._worksheet.cell(row=i + c_min_row, column=c_col, value=category)

        value_col_letter = openpyxl.utils.get_column_letter(v_col)
        self._worksheet[f'{value_col_letter}{v_min_row}'] = 'Frequency'
        self._worksheet[f'{value_col_letter}{v_min_row + 1}'] = f'=COUNTIF({self._table_name}[{gains_header}], ">0")'
        self._worksheet[f'{value_col_letter}{v_min_row + 2}'] = f'=COUNTIF({self._table_name}[{gains_header}], "<0")'

    def create_win_rate_chart(
            self, l_min_col: int, l_min_row: int, v_min_col: int, v_min_row: int, max_row: int, dest_cell: str
    ) -> None:
        d_chart = DoughnutChart(holeSize=50)
        d_chart.title = 'Win Rate'
        d_chart.legend = None

        labels = Reference(self._worksheet, min_col=l_min_col, min_row=l_min_row, max_row=max_row)
        values = Reference(self._worksheet, min_col=v_min_col, min_row=v_min_row, max_row=max_row)
        d_chart.add_data(values, titles_from_data=True)
        d_chart.set_categories(labels)

        series = d_chart.series[0]
        pt0 = DataPoint(idx=0)
        if pt0:
            pt0.graphicalProperties.solidFill = '80E408'
            series.dPt.append(pt0)
        pt1 = DataPoint(idx=1)
        if pt1:
            pt1.graphicalProperties.solidFill = 'EC034D'
            series.dPt.append(pt1)

        d_chart.dataLabels = DataLabelList()
        d_chart.dataLabels.showPercent = True

        self._worksheet.add_chart(d_chart, dest_cell)
