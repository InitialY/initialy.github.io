from image_number_extraction.extract.extract_config_factory import ExtractConfigFactory
from image_number_extraction.extract.create_game import CreateGame
import image_number_extraction.extract.extractor as extractor
from image_number_extraction.extract.game import Game


class GameCreator:
    config_presets: ExtractConfigFactory

    def __init__(self, config_preset):
        self.config_presets = config_preset

    def create_game(self, create: CreateGame, is_team: bool) -> Game:
        """
        Passes regions of the given CreateGame object and the corresponding extract config preset into the extract function.
        The extraction results are stored in a Game object which ultimately gets returned.
        The config preset needs to be passed as parameter when creating the GameCreator object.
        :param create: CreateGame object.
        :param is_team: bool flag to control the extraction of the placement region. Set this true if the tournament format is team.
        :return: Extracted integer values are stored in a Game object.
        """
        game = Game()
        if create.points is not None:
            points = extractor.extract(create.points_region, self.config_presets.get_points_config())
            points_sign = extractor.extract(create.points_region, self.config_presets.get_points_sign_config())
            game.points = (points_sign * points) if points_sign is not None and points is not None else game.points
            if not is_team:
                game.placement = extractor.extract(
                    create.placement_region, self.config_presets.get_placements_config()
                )
            else:
                game.placement = None
        if create.stats is not None:
            game.num_daruma = extractor.extract(create.daruma_region, self.config_presets.get_stats_config())
            game.num_kabuki = extractor.extract(create.kabuki_region, self.config_presets.get_stats_config())
            game.num_ippon = extractor.extract(create.ippon_region, self.config_presets.get_stats_config())
            game.num_ko = extractor.extract(create.ko_region, self.config_presets.get_stats_config())
        return game
