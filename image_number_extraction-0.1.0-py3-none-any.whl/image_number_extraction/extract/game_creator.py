from image_number_extraction.extract.extract_config_factory import ExtractConfigFactory
from image_number_extraction.extract.create_game import CreateGame
from image_number_extraction.extract.extractor import Extractor
from image_number_extraction.extract.game import Game


class GameCreator:
    extractor: Extractor
    config_presets: ExtractConfigFactory

    def __init__(self, config_preset):
        self.extractor = Extractor()
        self.config_presets = config_preset

    def create_game(self, create: CreateGame, is_team) -> Game:
        game = Game()
        if create.points is not None:
            points = self.extractor.extract(create.points_region, self.config_presets.get_points_config())
            points_sign = self.extractor.extract(create.points_region, self.config_presets.get_points_sign_config())
            game.points = (points_sign * points) if points_sign is not None and points is not None else game.points
            if not is_team:
                game.placement = self.extractor.extract(
                    create.placement_region, self.config_presets.get_placements_config()
                )
            else:
                game.placement = None
        if create.stats is not None:
            game.num_daruma = self.extractor.extract(create.daruma_region, self.config_presets.get_stats_config())
            game.num_kabuki = self.extractor.extract(create.kabuki_region, self.config_presets.get_stats_config())
            game.num_ippon = self.extractor.extract(create.ippon_region, self.config_presets.get_stats_config())
            game.num_ko = self.extractor.extract(create.ko_region, self.config_presets.get_stats_config())
        return game
