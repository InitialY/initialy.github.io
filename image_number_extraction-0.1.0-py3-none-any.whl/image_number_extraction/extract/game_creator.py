from typing import List

from image_number_extraction.extract.extract_config_factory import ExtractConfigFactory
from image_number_extraction.extract.game_image_region import GameImageRegion
import image_number_extraction.extract.extractor as extractor
from image_number_extraction.extract.game import Game
from image_number_extraction.prepare.image_processor import check_color_appearance


class GameCreator:
    config_presets: ExtractConfigFactory

    def __init__(self, config_preset):
        self.config_presets = config_preset

    def create_game(self, game_image_region: GameImageRegion, timestamp: str, is_team: bool) -> Game:
        """
        Passes regions of the given GameImageRegion object and the corresponding extract config preset into the extract function.
        The extraction results are stored in a Game object which ultimately gets returned.
        The config preset needs to be passed as parameter when creating the GameCreator object.
        :param game_image_region: GameImageRegion object.
        :param timestamp: timestamp string in ISO 8601 format.
        :param is_team: bool flag to control the extraction of the placement region. Set this true if the tournament format is team.
        :return: Extracted integer values are stored in a Game object.
        """
        game = Game(timestamp=timestamp)
        if game_image_region.points is not None:
            points = extractor.extract(game_image_region.points_region, self.config_presets.get_points_config())
            points_sign = extractor.extract(game_image_region.points_region, self.config_presets.get_points_sign_config())
            game.points = (points_sign * points) if points_sign is not None and points is not None else game.points
            if not is_team:
                game.placement = check_color_appearance(game_image_region.placement_color_region)
                if not game.placement:
                    game.placement = extractor.extract(
                        game_image_region.placement_region, self.config_presets.get_placements_config()
                    )
            else:
                game.placement = None
        if game_image_region.stats is not None:
            game.num_daruma = extractor.extract(game_image_region.daruma_region, self.config_presets.get_stats_config())
            game.num_kabuki = extractor.extract(game_image_region.kabuki_region, self.config_presets.get_stats_config())
            game.num_ippon = extractor.extract(game_image_region.ippon_region, self.config_presets.get_stats_config())
            game.num_ko = extractor.extract(game_image_region.ko_region, self.config_presets.get_stats_config())
        return game

