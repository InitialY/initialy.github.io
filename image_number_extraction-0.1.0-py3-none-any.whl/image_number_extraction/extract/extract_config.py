from dataclasses import dataclass
from typing import List, Any


@dataclass
class ExtractConfig:
    digit_templates: List[Any] = None
    template_character_mapping: List[str] = None
    matching_threshold: float = 0.92
    reset_range: int = 0
    start_index: int = 0
    max_number_of_digits: int = 1
