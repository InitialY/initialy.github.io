from dataclasses import dataclass
from typing import List, Any


@dataclass
class ExtractConfig:
    """
    This is used as a configuration object for the extract method of the Extractor class.

    This gets created when instantiating the ExtractConfigFactory class which is needed for the GameCreator.
    The create_game method of GameCreator eventually calls the extract method of the Extractor class.

    Attributes:
        digit_templates: List of modified opencv images.
        template_character_mapping: List of int digits as string characters representing the digit_templates.
        matching_threshold: float value ranging from -1 to 1 to adjust matching condition for the opencv matchTemplate method.
        reset_range: int value. For a better matching result. Should be the min width of a digit template image.
        start_index: int value. The mapping between a digit template and the actual int digit is the index.
            The index normally starts at 0, but if there is not a digit template for 0, this value has to be set to 1.
            The mapping and therefore the whole template matching does not work when there are missing templates in between.
        max_number_of_digits: int value. Limits the digits of the searched number.
    """
    digit_templates: List[Any] = None
    template_character_mapping: List[str] = None
    matching_threshold: float = 0.92
    reset_range: int = 0
    start_index: int = 0
    max_number_of_digits: int = 1
