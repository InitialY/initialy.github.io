from dataclasses import dataclass


@dataclass
class CreateGame:
    points: None = None
    stats: None = None
    points_region: None = None
    placement_region: None = None
    daruma_region: None = None
    kabuki_region: None = None
    ippon_region: None = None
    ko_region: None = None
