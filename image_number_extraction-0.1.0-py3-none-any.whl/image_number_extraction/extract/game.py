from dataclasses import dataclass
from typing import Optional


@dataclass
class Game:
    points: Optional[int] = None
    placement: Optional[int] = None
    num_daruma: Optional[int] = None
    num_kabuki: Optional[int] = None
    num_ippon: Optional[int] = None
    num_ko: Optional[int] = None

    def get_num_drones(self):
        if self.num_daruma and self.num_kabuki is not None:
            return self.num_daruma + self.num_kabuki
        else:
            return None

    def get_values(self):
        return self.placement, self.points, self.get_num_drones(), self.num_ippon, self.num_ko

    def __str__(self):
        return f'{self.placement}\t{self.points}\t{self.get_num_drones()}\t{self.num_ippon}\t{self.num_ko}'
