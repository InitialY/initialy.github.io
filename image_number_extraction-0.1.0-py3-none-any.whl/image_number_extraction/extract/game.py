from dataclasses import dataclass
from datetime import datetime


@dataclass
class Game:
    timestamp: str
    points: int | None = None
    placement: int | None = None
    num_daruma: int | None = None
    num_kabuki: int | None = None
    num_ippon: int | None= None
    num_ko: int | None = None

    def get_num_drones(self) -> int | None:
        if self.num_daruma and self.num_kabuki is not None:
            return self.num_daruma + self.num_kabuki
        else:
            return None

    def get_timestamp_time(self):
        dt = datetime.fromisoformat(self.timestamp)
        return dt.time()

    def get_timestamp_date(self):
        dt = datetime.fromisoformat(self.timestamp)
        return dt.date()

    def __str__(self):
        return f'{self.timestamp}\t{self.placement}\t{self.points}\t{self.get_num_drones()}\t{self.num_ippon}\t{self.num_ko}'

    def __eq__(self, other):
        return (
                self.timestamp == other.timestamp and
                self.points == other.points and
                self.placement == other.placement and
                self.num_daruma == other.num_daruma and
                self.num_kabuki == other.num_kabuki and
                self.num_ippon == other.num_ippon and
                self.num_ko == other.num_ko
        )

    def __hash__(self):
        return hash((self.timestamp, self.points, self.placement, self.num_daruma, self.num_kabuki, self.num_ippon, self.num_ko))
