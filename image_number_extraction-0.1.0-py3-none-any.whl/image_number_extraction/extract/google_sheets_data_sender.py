import os.path
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from enum import Enum
from typing import List, Tuple, Any, Iterable, Callable, Union

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

from image_number_extraction.extract.tournament import Tournament

SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]


class GoogleType(Enum):
    text = "TEXT"
    number = "DOUBLE"
    date_time = "DATE_TIME"
    date = "DATE"


HEADERS = {
    "Tournament": [
        ("TID", GoogleType.number),
        ("Name", GoogleType.text),
        ("Team", GoogleType.text),
        ("Start", GoogleType.date_time),
        ("End", GoogleType.date_time),
        ("Starting Points", GoogleType.number),
        ("Rank", GoogleType.text),
    ],
    "Game": [
        ("TID", GoogleType.number),
        ("GID", GoogleType.number),
        ("Time", GoogleType.date_time),
        ("Points", GoogleType.number),
        ("Placement", GoogleType.text),
        ("Drones", GoogleType.number),
        ("IPPONs", GoogleType.number),
        ("K.O.s", GoogleType.number),
    ],
    "Tournament Detailed": [
        ("TID", GoogleType.number),
        ("GID", GoogleType.number),
        ("Time", GoogleType.date_time),
        ("Points", GoogleType.number),
        ("Placement", GoogleType.text),
        ("Drones", GoogleType.number),
        ("IPPONs", GoogleType.number),
        ("K.O.s", GoogleType.number),
        ("Points History", GoogleType.number),
        ("Tournament Label", GoogleType.text),
        ("Tournament Date", GoogleType.date),
        ("Tournament Format", GoogleType.text),
        ("Win", GoogleType.text),
        ("Rank", GoogleType.text),
        ("Total Points", GoogleType.number),
        ("Tot Avg Drones", GoogleType.number),
        ("Avg Drones TID", GoogleType.number),
        ("Avg Drones GID", GoogleType.number),
        ("Tot Avg IPPONs", GoogleType.number),
        ("Avg IPPONs TID", GoogleType.number),
        ("Avg IPPONs GID", GoogleType.number),
    ]
}


def create_google_table_columns(headers: List[Tuple[str, GoogleType]]) -> List[dict[str, Any]]:
    return [
        {"columnIndex": i, "columnName": name, "columnType": gtype.value}
        for i, (name, gtype) in enumerate(headers)
    ]


@dataclass(frozen=True)
class SheetInfo:
    sheet_name: str
    sheet_id: int
    table_name: str
    table_id: str
    row_end: int
    col_end: int


def authenticate(token_path: str = "../token.json", credentials_path: str = "../credentials.json") -> Credentials:
    creds = None
    if os.path.exists(token_path):
        creds = Credentials.from_authorized_user_file(token_path, SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(credentials_path, SCOPES)
            creds = flow.run_local_server(port=0)

        with open(token_path, "w") as f:
            f.write(creds.to_json())

    return creds


def extract_sheet_info(service, spreadsheet_id: str, sheet_order: List[str]) -> List[SheetInfo]:
    try:
        meta = service.spreadsheets().get(spreadsheetId=spreadsheet_id).execute()
    except HttpError:
        raise

    infos: List[SheetInfo] = []
    # each sheet has one table
    for sheet_title in sheet_order:
        sheet = next(x for x in meta["sheets"] if x["properties"]["title"] == sheet_title)
        properties = sheet["properties"]
        sheet_table = sheet["tables"][0]
        table_range = sheet_table["range"]

        infos.append(
            SheetInfo(
                sheet_name=sheet_title,
                sheet_id=properties["sheetId"],
                table_name=sheet_table["name"],
                table_id=sheet_table["tableId"],
                row_end=table_range["endRowIndex"],
                col_end=table_range["endColumnIndex"],
            )
        )
    return infos


def init_spreadsheet(service, spreadsheet_title: str) -> str:
    body = {"properties": {"title": spreadsheet_title}}
    spreadsheet = service.spreadsheets().create(body=body, fields="spreadsheetId").execute()
    return spreadsheet["spreadsheetId"]


def add_sheets_and_tables(service, spreadsheet_id: str, sheet_names: Iterable[str]) -> None:
    # create sheets
    sheet_ids_by_name = {}
    for name in sheet_names:
        response = service.spreadsheets().batchUpdate(
            spreadsheetId=spreadsheet_id,
            body={"requests": [{"addSheet": {"properties": {"title": name}}}]},
        ).execute()
        sheet_id = response["replies"][0]["addSheet"]["properties"]["sheetId"]
        sheet_ids_by_name[name] = sheet_id

    # create tables
    for name in sheet_names:
        sheet_id = sheet_ids_by_name[name]
        columns_list = create_google_table_columns(HEADERS[name])
        sheet_range = {
            "sheetId": sheet_id,
            "startRowIndex": 0,
            "endRowIndex": 1,
            "startColumnIndex": 0,
            "endColumnIndex": len(columns_list),
        }
        service.spreadsheets().batchUpdate(
            spreadsheetId=spreadsheet_id,
            body={
                "requests": [
                    {
                        "addTable": {
                            "table": {
                                "name": name,
                                "columnProperties": columns_list,
                                "range": sheet_range,
                            }
                        }
                    }
                ]
            },
        ).execute()


def delete_extra_default_sheet(service, spreadsheet_id: str) -> None:
    # delete the initial blank sheet created by Google (first one)
    meta = service.spreadsheets().get(spreadsheetId=spreadsheet_id).execute()
    default_sheet_id = meta["sheets"][0]["properties"]["sheetId"]
    service.spreadsheets().batchUpdate(
        spreadsheetId=spreadsheet_id,
        body={"requests": [{"deleteSheet": {"sheetId": default_sheet_id}}]},
    ).execute()


def init_fully_if_needed(service, spreadsheet_id_or_name: str | None) -> tuple[str, list[SheetInfo]] | None:
    sheet_order = list(HEADERS.keys())
    if not spreadsheet_id_or_name:
        return None

    try:
        spreadsheet_id: str = spreadsheet_id_or_name
        infos = extract_sheet_info(service, spreadsheet_id_or_name, sheet_order)
        return spreadsheet_id, infos
    except HttpError as e:
        status = e.resp.status
        if status not in (404, 400):
            raise

        spreadsheet_name: str = spreadsheet_id_or_name
        new_id = init_spreadsheet(service, spreadsheet_name)
        add_sheets_and_tables(service, new_id, sheet_order)
        delete_extra_default_sheet(service, new_id)

        infos = extract_sheet_info(service, new_id, sheet_order)
        return new_id, infos


def add_data_to_table(
        spreadsheet,
        spreadsheet_id: str,
        sheet_name: str,
        values: List[List[Any]],
        table_id: str,
        table_name: str,
        table_row_end: int,
        table_column_end: int,
        sheet_id: int,
) -> None:
    if not values:
        return

    spreadsheet.values().append(
        spreadsheetId=spreadsheet_id,
        range=sheet_name,
        valueInputOption="USER_ENTERED",
        body={"values": values},
    ).execute()

    new_table_row_len = table_row_end + len(values)
    spreadsheet.batchUpdate(
        spreadsheetId=spreadsheet_id,
        body={
            "requests": [
                {
                    "updateTable": {
                        "table": {
                            "tableId": table_id,
                            "name": table_name,
                            "range": {
                                "sheetId": sheet_id,
                                "startRowIndex": 0,
                                "endRowIndex": new_table_row_len,
                                "startColumnIndex": 0,
                                "endColumnIndex": table_column_end,
                            },
                        },
                        "fields": "*",
                    }
                }
            ]
        },
    ).execute()


def build_formulas() -> dict[str, Union[Callable[[Any], str], Callable[[Any, Any], str]]]:
    time_lookup = lambda index: f'=IF($B{index}="","", INDEX(Game!C:C, MATCH($B{index}&"|"&$A{index}, Game!B:B&"|"&Game!A:A, 0)))'
    points_lookup = lambda index: f'=IF($B{index}=\"\", \"\", INDEX(Game!D:D, MATCH($B{index}&"|"&$A{index}, Game!B:B&"|"&Game!A:A, 0)))'
    placement_lookup = lambda index: f'=IF($B{index}=\"\", \"\", INDEX(Game!E:E, MATCH($B{index}&"|"&$A{index}, Game!B:B&"|"&Game!A:A, 0)))'
    drones_lookup = lambda index: f'=IF($B{index}=\"\", \"\", INDEX(Game!F:F, MATCH($B{index}&"|"&$A{index}, Game!B:B&"|"&Game!A:A, 0)))'
    ippons_lookup = lambda index: f'=IF($B{index}=\"\", \"\", INDEX(Game!G:G, MATCH($B{index}&"|"&$A{index}, Game!B:B&"|"&Game!A:A, 0)))'
    ko_lookup = lambda index: f'=IF($B{index}=\"\", \"\", INDEX(Game!H:H, MATCH($B{index}&"|"&$A{index}, Game!B:B&"|"&Game!A:A, 0)))'

    points_history_lookup = lambda index, index2: (
        f'=IF(A{index}=\"\", \"\",'
        f'IF(COUNTIF($A$2:A{index},A{index})=1,'
        f' IFERROR(INDEX(Tournament!F:F, MATCH($A{index}, Tournament!A:A, 0)), 0) + D{index},'
        f' INDEX($I$1:I{index2}, MATCH(2,1/($A$1:A{index2}=A{index})))+D{index} ))'
    )

    tournament_label_lookup = lambda index: (
        f'=IF($A{index}=\"\", \"\", INDEX(Tournament!B:B, MATCH($A{index}, Tournament!A:A, 0)))'
        f' & \" — \" & TO_TEXT($K{index})'
    )
    tournament_date_lookup = lambda index: f'=DATE(YEAR(C{index}), MONTH(C{index}), DAY(C{index}))'
    tournament_format_lookup = lambda index: f'=IF($A{index}=\"\", \"\", INDEX(Tournament!C:C, MATCH($A{index}, Tournament!A:A, 0)))'
    win_lookup = lambda index: f'=IF($D{index}>=0,\"Win\",\"Lose\")'
    rank_lookup = lambda index: f'=IF($A{index}=\"\", \"\", INDEX(Tournament!G:G, MATCH($A{index}, Tournament!A:A, 0)))'

    total_points_lookup = lambda index: (
        "=SUMIFS('Tournament Detailed'!D:D, 'Tournament Detailed'!A:A, $A{index}) + "
        "INDEX(Tournament!F:F, MATCH($A{index}, Tournament!A:A, 0))"
    ).format(index="$" + "{index}")  # no-op; keeps template style below

    # Use the original string templates (not the .format) to avoid accidental changes:
    total_points_lookup = lambda index: (
        f"=SUMIFS('Tournament Detailed'!D:D, 'Tournament Detailed'!A:A, $A{index}) + "
        f"INDEX(Tournament!F:F, MATCH($A{index}, Tournament!A:A, 0))"
    )

    total_average_drones_lookup = lambda index: f"=ArrayFormula(AVERAGE(IF('Tournament Detailed'!L:L=$L{index}, 'Tournament Detailed'!F:F)))"
    average_drones_tid_lookup = lambda index: f"=ArrayFormula(AVERAGE(IF(('Tournament Detailed'!A:A=$A{index})*('Tournament Detailed'!L:L=$L{index}), 'Tournament Detailed'!F:F)))"
    average_drones_gid_lookup = lambda index: f"=ArrayFormula(AVERAGE(IF(('Tournament Detailed'!B:B=$B{index})*('Tournament Detailed'!L:L=$L{index}), 'Tournament Detailed'!F:F)))"

    total_average_ippons_lookup = lambda index: f"=ArrayFormula(AVERAGE(IF('Tournament Detailed'!L:L=$L{index}, 'Tournament Detailed'!G:G)))"
    average_ippons_tid_lookup = lambda index: f"=ArrayFormula(AVERAGE(IF(('Tournament Detailed'!A:A=$A{index})*('Tournament Detailed'!L:L=$L{index}), 'Tournament Detailed'!G:G)))"
    average_ippons_gid_lookup = lambda index: f"=ArrayFormula(AVERAGE(IF(('Tournament Detailed'!B:B=$B{index})*('Tournament Detailed'!L:L=$L{index}), 'Tournament Detailed'!G:G)))"

    return {
        "time": time_lookup,
        "points": points_lookup,
        "placement": placement_lookup,
        "drones": drones_lookup,
        "ippons": ippons_lookup,
        "ko": ko_lookup,
        "points_history": points_history_lookup,
        "tournament_label": tournament_label_lookup,
        "tournament_date": tournament_date_lookup,
        "tournament_format": tournament_format_lookup,
        "win": win_lookup,
        "rank": rank_lookup,
        "total_points": total_points_lookup,
        "total_average_drones": total_average_drones_lookup,
        "average_drones_tid": average_drones_tid_lookup,
        "average_drones_gid": average_drones_gid_lookup,
        "total_average_ippons": total_average_ippons_lookup,
        "average_ippons_tid": average_ippons_tid_lookup,
        "average_ippons_gid": average_ippons_gid_lookup,
    }


def build_values(
        tournaments: List[Tournament],
        table0_row_len: int,
        table2_row_len: int,
        date_time_format: str = "%Y-%m-%d %H:%M:%S"
) -> Tuple[List[List[Any]], List[List[Any]], List[List[Any]]]:
    tournament_values: List[List[Any]] = []
    games_values: List[List[Any]] = []

    for i, t in enumerate(tournaments):
        t_format = "Team" if t.is_team else "Solo"
        tournament_values.append(
            [
                i - 1 + table0_row_len,
                t.name,
                t_format,
                t.start_time.strftime(date_time_format),
                t.end_time.strftime(date_time_format),
                t.starting_points,
            ]
        )

        for g in t.games:
            games_values.append(
                [
                    f"=VLOOKUP(Tournament!$A{i + 1 + table0_row_len}, Tournament, 1, FALSE)",
                    g.game_id,
                    g.timestamp.strftime(date_time_format),
                    g.points,
                    g.placement,
                    g.get_num_drones(),
                    g.num_ippon,
                    g.num_ko,
                ]
            )

    formulas = build_formulas()
    tournament_detailed_values: List[List[Any]] = []

    for i, g in enumerate(games_values):
        i1 = i + 1 + table2_row_len
        i2 = i + table2_row_len

        tournament_detailed_values.append(
            [
                g[0],  # TID lookup formula from Tournament sheet
                g[1],  # GID
                formulas["time"](i1),
                formulas["points"](i1),
                formulas["placement"](i1),
                formulas["drones"](i1),
                formulas["ippons"](i1),
                formulas["ko"](i1),
                formulas["points_history"](i1, i2),
                formulas["tournament_label"](i1),
                formulas["tournament_date"](i1),
                formulas["tournament_format"](i1),
                formulas["win"](i1),
                formulas["rank"](i1),
                formulas["total_points"](i1),
                formulas["total_average_drones"](i1),
                formulas["average_drones_tid"](i1),
                formulas["average_drones_gid"](i1),
                formulas["total_average_ippons"](i1),
                formulas["average_ippons_tid"](i1),
                formulas["average_ippons_gid"](i1),
            ]
        )

    return tournament_values, games_values, tournament_detailed_values


def sheets_serial_to_datetime(serial: float, tzinfo=timezone.utc) -> datetime:
    # Sheets: day 0 = 1899-12-30
    base = datetime(1899, 12, 30, tzinfo=tzinfo)
    return base + timedelta(days=float(serial))


def check_for_tournament_duplicates(
        service,
        spreadsheet_id: str,
        tournament_date_column_range: str,
        tournaments: List[Tournament]
) -> List[Tournament]:
    response = service.spreadsheets().values().get(
        spreadsheetId=spreadsheet_id,
        range=tournament_date_column_range,
        majorDimension="COLUMNS",
        valueRenderOption="UNFORMATTED_VALUE",
        dateTimeRenderOption="SERIAL_NUMBER",
    ).execute()

    values = response.get("values", [])
    first_row = values[0] if values else []
    column_values_set = set(first_row)

    sheets_date_values_set = {
        sheets_serial_to_datetime(float(v))
        for v in column_values_set
    }


    filtered_tournaments: List[Tournament] = []
    for t in tournaments:
        if t.start_time not in sheets_date_values_set:
            filtered_tournaments.append(t)
    return filtered_tournaments


def send_data(tournaments: List[Tournament], spreadsheet_id: str | None = None) -> None:
    try:
        creds = authenticate()
        service = build("sheets", "v4", credentials=creds)
        spreadsheet_id, sheet_infos = init_fully_if_needed(service, spreadsheet_id)

        info_by_name = {si.sheet_name: si for si in sheet_infos}
        info_t = info_by_name["Tournament"]
        info_g = info_by_name["Game"]
        info_d = info_by_name["Tournament Detailed"]

        spreadsheet = service.spreadsheets()

        date_end_row: int = 2 if info_t.row_end < 2 else info_t.row_end
        tournament_date_column_range: str = f"\'Tournament\'!D2:D{date_end_row}"
        filtered_tournaments: List[Tournament] = check_for_tournament_duplicates(
            service, spreadsheet_id, tournament_date_column_range, tournaments
        )

        tournament_values, games_values, tournament_detailed_values = build_values(
            tournaments=filtered_tournaments,
            table0_row_len=info_t.row_end,
            table2_row_len=info_g.row_end,
        )

        add_data_to_table(
            spreadsheet=spreadsheet,
            spreadsheet_id=spreadsheet_id,
            sheet_name=info_t.sheet_name,
            values=tournament_values,
            table_id=info_t.table_id,
            table_name=info_t.table_name,
            table_row_end=info_t.row_end,
            table_column_end=info_t.col_end,
            sheet_id=info_t.sheet_id,
        )
        add_data_to_table(
            spreadsheet=spreadsheet,
            spreadsheet_id=spreadsheet_id,
            sheet_name=info_g.sheet_name,
            values=games_values,
            table_id=info_g.table_id,
            table_name=info_g.table_name,
            table_row_end=info_g.row_end,
            table_column_end=info_g.col_end,
            sheet_id=info_g.sheet_id,
        )
        add_data_to_table(
            spreadsheet=spreadsheet,
            spreadsheet_id=spreadsheet_id,
            sheet_name=info_d.sheet_name,
            values=tournament_detailed_values,
            table_id=info_d.table_id,
            table_name=info_d.table_name,
            table_row_end=info_d.row_end,
            table_column_end=info_d.col_end,
            sheet_id=info_d.sheet_id,
        )
    except HttpError as err:
        print(err)
