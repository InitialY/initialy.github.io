from typing import List, Tuple, Optional, TypeAlias

import numpy as np
import cv2
import numpy.typing as npt
from cv2.typing import MatLike

from image_number_extraction.extract.extract_config import ExtractConfig

CV2Image: TypeAlias = MatLike


def __create_highscore_candidates(
        input_image: CV2Image, digit_templates: List[CV2Image], template_character_mapping: List[str]
) -> Tuple[npt.NDArray[float], npt.NDArray[str]]:
    """
    use matchTemplate function of opencv for every given template.
    The result tuple contains
    highscore_candidates: numpy float array
    (the highest matching float value for every column in input_image across all given templates)
    and mapping_chars_array: numpy str array
    (the corresponding mapped digit templates as strings)
    """
    max_per_col_all_templates = []
    for template in digit_templates:
        result = cv2.matchTemplate(input_image, template, cv2.TM_CCOEFF_NORMED)
        max_per_col: npt.NDArray[float] = np.max(result, axis=0)
        max_per_col_all_templates.append(max_per_col)

    # convert results to numpy 2d matrix; match result matrix sizes differs, fill empty spots with -1
    max_len: int = max(len(max_per_col) for max_per_col in max_per_col_all_templates)
    max_per_col_all_templates_matrix: npt.NDArray[float] = np.full((len(max_per_col_all_templates), max_len), -1.0)
    for i, max_per_col in enumerate(max_per_col_all_templates):
        max_per_col_all_templates_matrix[i, :len(max_per_col)] = max_per_col

    highscore_candidates: npt.NDArray[float] = np.max(max_per_col_all_templates_matrix, axis=0)
    max_indices: npt.NDArray[int] = np.argmax(max_per_col_all_templates_matrix, axis=0)
    mapping_chars: List[str] = [template_character_mapping[max_index] for max_index in max_indices]
    mapping_chars_array: npt.NDArray[str] = np.array(mapping_chars)

    return highscore_candidates, mapping_chars_array


def __get_best_match(
        highscore_candidates: npt.NDArray[float], highscore_candidate_mapping: npt.NDArray[str]
) -> Tuple[float, int, str]:
    """
    Simple approach used: if there are multiple indices the first one will be used.
    """
    position_index: int = np.argmax(highscore_candidates).astype(int)
    matching_value: float = float(highscore_candidates[position_index])
    mapping_char: str = str(highscore_candidate_mapping[position_index])
    return matching_value, position_index, mapping_char


def __reset_matching_values(
        highscore_candidates: npt.NDArray[float],
        index: int,
        reset_range: int = 0,
        reset_value: int = -1
) -> npt.NDArray[float]:
    highscore_candidates_copy: npt.NDArray[float] = highscore_candidates.copy()
    highscore_candidates_copy[index] = reset_value
    start_index = max(0, index - reset_range)
    end_index = min(len(highscore_candidates_copy), index + reset_range + 1)
    highscore_candidates_copy[start_index:end_index] = reset_value
    return highscore_candidates_copy


def __get_n_best_records(
        n: int, highscore_candidates: npt.NDArray[float], highscore_candidate_mapping: npt.NDArray[str],
        reset_range: int
) -> List[Tuple[float, int, str]]:
    # i_max_index is the image position
    records = []
    for i in range(n):
        i_max_value, i_max_index, i_mapping_char = \
            __get_best_match(highscore_candidates, highscore_candidate_mapping)
        highscore_candidates = __reset_matching_values(
            highscore_candidates, i_max_index, reset_range
        )
        records.append((i_max_value, i_max_index, i_mapping_char))
    return records


def __filter_records(
        records: List[Tuple[float, int, str]], matching_threshold: float
) -> List[Optional[Tuple[float, int, str]]]:
    filtered_records = [record for record in records if record[0] > matching_threshold]
    return filtered_records


def __merge_mapping_chars(records: List[Tuple[float, int, str]]) -> int | None:
    if len(records) == 0:
        return None

    records.sort(key=lambda rec: rec[1])
    number = ''
    for record in records:
        number += record[2]
    return int(number)


def __get_number(
        highscore_candidates: npt.NDArray[float],
        highscore_candidate_mapping: npt.NDArray[str],
        max_number_of_digits: int,
        reset_range: int,
        matching_threshold: float
) -> int | None:
    records: List[Tuple[float, int, str]] = __get_n_best_records(
        max_number_of_digits, highscore_candidates, highscore_candidate_mapping, reset_range
    )
    filtered_records: List[Tuple[float, int, str]] = __filter_records(records, matching_threshold)
    number: int | None = __merge_mapping_chars(filtered_records)
    return number


def extract(image: CV2Image, extract_config: ExtractConfig) -> int | None:
    """
    Takes an opencv image and extracts integer values with the opencv method matchTemplate.
    All config is taken from the given extract_config. If the extraction fails, it returns None.
    :param extract_config: ExtractConfig object containing config parameters.
    :param image: Modified opencv image region for extracting number.
    :return: positive int number or None.
    """
    highscore_candidates, highscore_candidate_mapping = __create_highscore_candidates(
        image, extract_config.digit_templates, extract_config.template_character_mapping
    )
    number: int | None = __get_number(
        highscore_candidates, highscore_candidate_mapping, extract_config.max_number_of_digits,
        extract_config.reset_range,
        extract_config.matching_threshold
    )
    return number
