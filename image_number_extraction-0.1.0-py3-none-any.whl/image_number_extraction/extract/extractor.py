from typing import List, Tuple, Optional

import numpy as np
import cv2
import numpy.typing as npt

from image_number_extraction.extract.extract_config import ExtractConfig


class Extractor:

    @staticmethod
    def _match_templates(input_image, digit_templates) -> List[npt.NDArray[float]]:
        """
        The result is a list of numpy 1d float array containing the highest matching value of each column
        for every digit template.
        Matching value is a float value between -1 and +1.
        """
        results = []
        for template in digit_templates:
            result = cv2.matchTemplate(input_image, template, cv2.TM_CCOEFF_NORMED)
            # clamp 2D result array into a 1D array by taking the max value
            result_1d: npt.NDArray[float] = np.max(result, axis=0)
            results.append(result_1d)
        return results

    @staticmethod
    def _transform_to_2darray(result: List[npt.NDArray[float]]) -> npt.NDArray[float]:
        """
        Takes the list of 1d numpy arrays returned by _match_templates and transforms it to a 2d numpy array.
        For this, the empty spots are filled with -1, the lowest matching value.
        :param result: list of 1d numpy arrays. Use the method _match_templates.
        :return: 2d numpy array with float values ranging from -1 to 1
        """
        max_length = max(len(result_entry) for result_entry in result)
        array_2d: npt.NDArray[float] = np.full((len(result), max_length), -1.0)
        for i, result_entry in enumerate(result):
            array_2d[i, :len(result_entry)] = result_entry
        return array_2d

    @staticmethod
    def _reduce_match_templates_result(array_2d: npt.NDArray[float], template_character_mapping: List[str]):
        """
        takes column-wise the highest matching value and the corresponding row index (plus the offset start_index)
        and stores them as a tuple in a numpy array. The row index happens to be the same as the template digit.
        So, for example, the digit 1 also has the row index 1. That is, if there are templates ranging from 0 to n.
        If, for example, there is no template for 0, a start_index can be defined and will be added as an offset.
        :param array_2d: 2d numpy array. Use the method _parse_match_templates_result.
        :return: a numpy 2d float array with 2 rows and a variing length or number of columns.
        """
        highscore_candidates: npt.NDArray[float] = np.max(array_2d, axis=0)
        max_indices: npt.NDArray[int] = np.argmax(array_2d, axis=0)
        mapping_chars: List[str] = [template_character_mapping[max_index] for max_index in max_indices]
        mapping_chars_array: npt.NDArray[str] = np.array(mapping_chars)
        return highscore_candidates, mapping_chars_array

    @staticmethod
    def _create_highscore_candidates(image, templates, template_character_mapping: List[str]):
        result: List[npt.NDArray[float]] = Extractor._match_templates(input_image=image, digit_templates=templates)
        array_2d: npt.NDArray[float] = Extractor._transform_to_2darray(result)
        highscore_candidates, highscore_candidate_mapping = \
            Extractor._reduce_match_templates_result(array_2d, template_character_mapping)
        return highscore_candidates, highscore_candidate_mapping

    @staticmethod
    def _get_best_match(highscore_candidates: npt.NDArray[float], highscore_candidate_mapping: npt.NDArray[str]):
        """
        Simple approach used: if there are multiple indices the first one will be used.
        """
        position_index: int = np.argmax(highscore_candidates)
        matching_value: float = highscore_candidates[position_index]
        mapping_char: str = highscore_candidate_mapping[position_index]
        return matching_value, position_index, mapping_char

    @staticmethod
    def _reset_matching_values(
            highscore_candidates: npt.NDArray[float],
            index: int,
            reset_range: int = 0,
            reset_value: int = -1
    ):
        highscore_candidates_copy = highscore_candidates.copy()
        highscore_candidates_copy[index] = reset_value
        start_index = max(0, index - reset_range)
        end_index = min(len(highscore_candidates_copy), index + reset_range + 1)
        highscore_candidates_copy[start_index:end_index] = reset_value
        return highscore_candidates_copy

    @staticmethod
    def _get_n_highest_matching_records(
            n: int, highscore_candidates: npt.NDArray[float], highscore_candidate_mapping: npt.NDArray[str], reset_range: int
    ) -> List[Tuple[float, int, str]]:
        # i_max_value_index is the image position
        records = []
        for i in range(n):
            i_max_matching_value, i_max_value_index, i_mapping_char = \
                Extractor._get_best_match(highscore_candidates, highscore_candidate_mapping)
            highscore_candidates = Extractor._reset_matching_values(
                highscore_candidates, i_max_value_index, reset_range
            )
            records.append((i_max_matching_value, i_max_value_index, i_mapping_char))
        return records

    @staticmethod
    def _filter_matching_records(
            records: List[Tuple[float, int, str]], matching_threshold: float
    ) -> List[Optional[Tuple[float, int, str]]]:
        # careful, this can return an empty list!
        filtered_records = [record for record in records if record[0] > matching_threshold]
        return filtered_records

    @staticmethod
    def _fuse_record_digits_to_number(records) -> Optional[int]:
        if len(records) == 0:
            return None

        records.sort(key=lambda rec: rec[1])    # rec[1] is the image position
        number = ''
        for record in records:
            number += record[2]
        return int(number)

    @staticmethod
    def _reduce_to_digits(
            highscore_candidates: npt.NDArray[float],
            highscore_candidate_mapping: npt.NDArray[str],
            max_number_of_digits: int,
            reset_range: int,
            matching_threshold: float
    ) -> Optional[int]:
        records: List[Tuple[float, int, str]] = Extractor._get_n_highest_matching_records(
            max_number_of_digits, highscore_candidates, highscore_candidate_mapping, reset_range
        )
        filtered_records: List[Tuple[float, int, str]] = Extractor._filter_matching_records(records, matching_threshold)
        digits: Optional[int] = Extractor._fuse_record_digits_to_number(filtered_records)
        return digits

    @staticmethod
    def extract(image, extract_config: ExtractConfig) -> Optional[int]:
        """
        Takes elements of digit_templates list and checks, if it appears in the given image. Therefore, the opencv
        method matchTemplate is used. matchTemplate returns match values. The higher the value, the higher the match.
        The returning digits can be filtered with the giving matching_threshold, the default is 0.
        :param extract_config:
        :param image: Modified opencv image region for extracting digits.
        :param digit_templates: List of modified opencv images. used for the template matching.
        :param matching_threshold: float value from -1 to 1 to adjust matching condition.
        :param reset_range: int value. For a better matching result. Should be the min width of a digit template image.
        :param start_index: int value. The mapping between a digit template and the actual int digit is the index.
        The index normally starts at 0, but if there is not a digit template for 0, this value has to be set to 1.
        The mapping and therefore the whole template matching does not work when there are missing templates in between.
        :param max_number_of_digits: int value. Limits the digits of the searched number.
        :return: positive int number
        """
        highscore_candidates, highscore_candidate_mapping = Extractor._create_highscore_candidates(
            image, extract_config.digit_templates, extract_config.template_character_mapping
        )
        digits: Optional[int] = Extractor._reduce_to_digits(
            highscore_candidates, highscore_candidate_mapping, extract_config.max_number_of_digits, extract_config.reset_range,
            extract_config.matching_threshold
        )
        return digits
