from dataclasses import dataclass
from typing import TypeAlias

from cv2.typing import MatLike

CV2Image: TypeAlias = MatLike | None

@dataclass
class GameImageRegion:
    """
    This class is an intermediate type containing two images (points and stats) read with the opencv library,
    and various modified image regions of the two images. Default values are None.
    """
    points: CV2Image = None
    stats: CV2Image = None
    points_region: CV2Image = None
    placement_region: CV2Image = None
    placement_color_region: CV2Image = None
    daruma_region: CV2Image = None
    kabuki_region: CV2Image = None
    ippon_region: CV2Image = None
    ko_region: CV2Image = None
