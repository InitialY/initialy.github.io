from dataclasses import dataclass, asdict, field
from typing import List, Union, Optional
import re

from image_number_extraction.extract.game import Game


@dataclass
class Tournament:
    name: str
    short_name: Optional[str] = field(default=None)
    total_points: Optional[int] = field(default=None)
    starting_points: int = 500
    games: List[Game] = field(default_factory=list)

    def __post_init__(self):
        for name, field in self.__dataclass_fields__.items():
            if method := getattr(self, f"validate_{name}", None):
                setattr(self, name, method(getattr(self, name), field=field))

    @property
    def current_points(self) -> List[int]:
        current_points = [self.starting_points]
        points_list = [game.points for game in self.games]
        for i in range(len(points_list)):
            curr_p = current_points[-1]
            if points_list[i] is not None:
                curr_p += points_list[i]
            current_points.append(curr_p)
        return current_points

    @property
    def get_points_list(self) -> List[int]:
        return [game.points for game in self.games]

    @property
    def gained_points(self) -> int:
        points_list = [game.points for game in self.games if game.points is not None]
        gained_points_generator = (points for points in points_list if points >= 0)
        return sum(gained_points_generator)

    @property
    def lost_points(self) -> int:
        points_list = [game.points for game in self.games if game.points is not None]
        lost_points_generator = (points for points in points_list if points < 0)
        return sum(lost_points_generator)

    @property
    def average_points(self) -> float:
        if len(self.games) == 0:
            return .0
        return round(self.gained_points / len(self.games), 2)

    @property
    def total_drones(self) -> int:
        drones = []
        for game in self.games:
            if game.num_daruma and game.num_kabuki is not None:
                drones.append(game.num_daruma + game.num_kabuki)
        return sum(drones)

    @property
    def average_drones(self) -> float:
        if len(self.games) == 0:
            return .0
        drones = (game.num_daruma + game.num_kabuki for game in self.games)
        return round(sum(drones) / len(self.games), 2)

    @property
    def total_ippons(self) -> int:
        ippon_list = [game.num_ippon for game in self.games if game.num_ippon is not None]
        return sum(ippon_list)

    @property
    def average_ippons(self) -> float:
        if len(self.games) == 0:
            return .0
        ippon_list = [game.num_ippon for game in self.games if game.num_ippon is not None]
        return round(sum(ippon_list) / len(self.games), 2)

    @property
    def total_kos(self) -> int:
        ko_list = [game.num_ko for game in self.games if game.num_ko is not None]
        return sum(ko_list)

    @property
    def average_kos(self) -> float:
        if len(self.games) == 0:
            return .0
        ko_list = [game.num_ko for game in self.games if game.num_ko is not None]
        return round(sum(ko_list) / len(self.games), 2)

    def get_placement_frequencies(self) -> List[List[Union[str, int]]]:
        placement_frequencies: List[List[Union[str, int]]] = [
            ['Placement', 'Frequency'], [1, 0], [2, 0], [3, 0], [4, 0], [5, 0], [6, 0], [7, 0], [8, 0]
        ]
        for game in self.games:
            if game.placement is not None:
                placement_frequencies[game.placement][1] += 1
        return placement_frequencies

    def get_win_rate(self) -> List[List[Union[str, int]]]:
        win_rate: List[List[Union[str, int]]] = [[None, 'Frequency'], ['Win 1-4', 0], ['Lose 5-8', 0]]
        for game in self.games:
            if game.placement is not None:
                if game.placement <= 4:
                    win_rate[1][1] += 1
                if game.placement > 4:
                    win_rate[2][1] += 1
        return win_rate

    def get_game_values(self):
        result = [(None, self.starting_points, None, None, None)]
        for i, game in enumerate(self.games):
            result.append((i + 1, None, *game.get_values()))
        return result

    def get_dict_repr(self):
        return asdict(self)

    def __str__(self):
        result = [f'{self.starting_points}']
        for i, game in enumerate(self.games):
            result.append(f'{i + 1}\t{self.current_points[i + 1]}\t{game}')
        return '\n'.join(result)

    def validate_short_name(self, value, **_) -> str:
        pattern: str = "^[A-Za-z0-9_]*$"
        if re.fullmatch(pattern, value):
            return value
        else:
            raise ValueError('Invalid Short Name.')

    def validate_total_points(self, value, **_) -> int:
        return int(value)
