from dataclasses import dataclass, asdict, field
from typing import List, Tuple
from re import fullmatch

from image_number_extraction.extract.game import Game


@dataclass
class Tournament:
    name: str
    short_name: str | None = field(default=None)
    starting_points: int = 500
    games: List[Game] = field(default_factory=list)

    def __post_init__(self):
        for name, f in self.__dataclass_fields__.items():
            if method := getattr(self, f"validate_{name}", None):
                setattr(self, name, method(getattr(self, name), f=field))

    @property
    def get_points_list(self) -> List[int | None]:
        return [game.points for game in self.games]

    @property
    def get_filtered_points_list(self) -> List[int]:
        return [game.points for game in self.games if game.points is not None]

    def get_current_points_list(self) -> List[int]:
        current_points_list: List[int] = [self.starting_points]
        for i in range(len(self.get_points_list)):
            current_points = current_points_list[-1]
            if self.get_points_list[i] is not None:
                current_points += self.get_points_list[i]
            current_points_list.append(current_points)
        return current_points_list

    @property
    def total_points(self) -> int:
        return self.get_current_points_list()[-1]

    @property
    def max_points(self) -> int | None:
        return max(self.get_filtered_points_list, default=None)

    @property
    def min_points(self) -> int | None:
        return min(self.get_filtered_points_list, default=None)

    @property
    def largest_loss(self) -> int | None:
        if self.min_points is None:
            return None
        return self.min_points if self.min_points <= 0 else None

    @property
    def total_gained_points(self) -> int:
        return self.total_points - self.starting_points

    @property
    def total_earned_points(self) -> int | None:
        if not self.get_filtered_points_list:
            return None
        positive_points = [points for points in self.get_filtered_points_list if points >= 0]
        return sum(positive_points) if positive_points else None

    @property
    def total_lost_points(self) -> int | None:
        if not self.get_filtered_points_list:
            return None
        negative_points = [points for points in self.get_filtered_points_list if points < 0]
        return sum(negative_points) if negative_points else None

    @property
    def average_points(self) -> int | None:
        return round(self.total_gained_points / len(self.games), 2) if self.games and self.total_gained_points else None

    @property
    def total_drones(self) -> int | None:
        filtered_drones: List[int] = [game.get_num_drones() for game in self.games if game.get_num_drones() is not None]
        return sum(filtered_drones) if filtered_drones else None

    @property
    def average_drones(self) -> int | None:
        return round(self.total_drones / len(self.games), 2)  if self.games and self.total_drones else None

    @property
    def total_ippons(self) -> int | None:
        filtered_ippon_list: List[int] = [game.num_ippon for game in self.games if game.num_ippon is not None]
        return sum(filtered_ippon_list) if filtered_ippon_list else None

    @property
    def average_ippons(self) -> int | None:
        return round(self.total_ippons / len(self.games), 2) if self.games and self.total_ippons else None

    @property
    def total_kos(self) -> int | None:
        filtered_ko_list = [game.num_ko for game in self.games if game.num_ko is not None]
        return sum(filtered_ko_list) if filtered_ko_list else None

    @property
    def average_kos(self) -> int | None:
        return round(self.total_kos / len(self.games), 2) if self.games and self.total_kos else None

    def get_placement_frequencies(self) -> List[int]:
        placement_frequencies: List[int] = [0] * 8
        for game in self.games:
            if game.placement is not None and 1 <= game.placement <= 8:
                placement_frequencies[game.placement-1] += 1
        return placement_frequencies

    def get_win_lose(self) -> Tuple[int, int]:
        wins = sum(1 for game in self.games if game.placement is not None and 1 <= game.placement <= 4)
        losses = sum(1 for game in self.games if game.placement is not None and 8 >= game.placement > 4)
        return wins, losses

    def get_game_values(self):
        result = [(None, self.starting_points, None, None, None)]
        for i, game in enumerate(self.games):
            result.append((i + 1, None, *game.get_values()))
        return result

    def get_dict_repr(self):
        return asdict(self)

    def get_summary(self):
        return {
            'Tournament Name': self.name,
            'Total Points': self.total_points,
            'Played Games': len(self.games),
            'Average Points': self.average_points,
            'Largest Gain': self.max_points,
            'Largest Loss': self.largest_loss,
            'Total Gained Points': self.total_gained_points,
            'Total Earned Points': self.total_earned_points,
            'Total Lost Points': self.total_lost_points,
            'Win Rate': self.get_win_lose(),
            'Placement Frequencies': self.get_placement_frequencies(),
            'Average IPPONs': self.average_ippons,
            'Total IPPONs': self.total_ippons,
            'Average Drones': self.average_drones,
            'Total Drones': self.total_drones,
            'Average KOs': self.average_kos,
            'Total KOs': self.total_kos,
            'Current Points': self.get_current_points_list(),
            'Points': self.get_points_list,
            'Games': self.games
        }

    def __str__(self):
        result = [f'{self.starting_points}']
        current_points_list = self.get_current_points_list()
        for i, game in enumerate(self.games):
            result.append(f'{i + 1}\t{current_points_list[i + 1]}\t{game}')
        return '\n'.join(result)

    @staticmethod
    def validate_short_name(value, **_) -> str | None:
        if value is None:
            return None
        pattern: str = '^([A-Za-z_][A-Za-z0-9_]*|)$'
        if fullmatch(pattern, value):
            return value
        else:
            raise ValueError(
                'Invalid Short Name: must start with a letter or underscore and only contain letters, numbers, and underscores.')

    def __eq__(self, other):
        return (
                self.name == other.name and
                self.short_name == other.short_name and
                self.starting_points == other.starting_points and
                self.games == other.games
        )

    def __hash__(self):
        return hash((self.name, self.short_name, self.starting_points, tuple(self.games)))
