from dataclasses import dataclass, asdict, field
from typing import List, Tuple
from re import fullmatch

from image_number_extraction.extract.game import Game


@dataclass
class Tournament:
    name: str
    short_name: str | None = field(default=None)
    starting_points: int = 500
    games: List[Game] = field(default_factory=list)

    def __post_init__(self):
        for name, f in self.__dataclass_fields__.items():
            if method := getattr(self, f"validate_{name}", None):
                setattr(self, name, method(getattr(self, name), f=field))

    @property
    def current_points(self) -> List[int]:
        current_points = [self.starting_points]
        points_list = [game.points for game in self.games]
        for i in range(len(points_list)):
            curr_p = current_points[-1]
            if points_list[i] is not None:
                curr_p += points_list[i]
            current_points.append(curr_p)
        return current_points

    @property
    def get_points_list(self) -> List[int]:
        return [game.points for game in self.games]

    @property
    def max_points(self) -> int | None:
        filtered_points = list(filter(lambda game: game.points is not None, self.games))
        return max(filtered_points, key=lambda game: game.points).points if filtered_points else None

    @property
    def min_points(self) -> int | None:
        filtered_points = list(filter(lambda game: game.points is not None, self.games))
        return min(filtered_points, key=lambda game: game.points).points if filtered_points else None

    @property
    def largest_loss(self) -> int | None:
        return self.min_points if self.min_points and self.min_points <= 0 else None

    @property
    def gained_points(self) -> int:
        points_list = [game.points for game in self.games if game.points is not None]
        gained_points_generator = (points for points in points_list if points >= 0)
        return sum(gained_points_generator)

    @property
    def lost_points(self) -> int:
        points_list = [game.points for game in self.games if game.points is not None]
        lost_points_generator = (points for points in points_list if points < 0)
        return sum(lost_points_generator)

    @property
    def total_points(self) -> int:
        return self.current_points[-1]

    @property
    def average_points(self) -> float:
        if len(self.games) == 0:
            return .0
        return round(self.gained_points / len(self.games), 2)

    @property
    def total_drones(self) -> int:
        drones = []
        for game in self.games:
            if game.num_daruma and game.num_kabuki is not None:
                drones.append(game.num_daruma + game.num_kabuki)
        return sum(drones)

    @property
    def average_drones(self) -> float:
        if len(self.games) == 0:
            return .0
        drones = ((game.num_daruma or 0) + (game.num_kabuki or 0) for game in self.games)
        return round(sum(drones) / len(self.games), 2)

    @property
    def total_ippons(self) -> int:
        ippon_list = [game.num_ippon for game in self.games if game.num_ippon is not None]
        return sum(ippon_list)

    @property
    def average_ippons(self) -> float:
        if len(self.games) == 0:
            return .0
        ippon_list = [game.num_ippon for game in self.games if game.num_ippon is not None]
        return round(sum(ippon_list) / len(self.games), 2)

    @property
    def total_kos(self) -> int:
        ko_list = [game.num_ko for game in self.games if game.num_ko is not None]
        return sum(ko_list)

    @property
    def average_kos(self) -> float:
        if len(self.games) == 0:
            return .0
        ko_list = [game.num_ko for game in self.games if game.num_ko is not None]
        return round(sum(ko_list) / len(self.games), 2)

    def get_placement_frequencies(self) -> List[int]:
        placement_frequencies: List[int] = [0] * 8
        for game in self.games:
            if game.placement is not None and 1 <= game.placement <= 8:
                placement_frequencies[game.placement-1] += 1
        return placement_frequencies

    def get_win_lose(self) -> Tuple[int, int]:
        wins = sum(1 for game in self.games if game.placement is not None and game.placement <= 4)
        losses = sum(1 for game in self.games if game.placement is not None and game.placement > 4)
        return wins, losses

    def get_game_values(self):
        result = [(None, self.starting_points, None, None, None)]
        for i, game in enumerate(self.games):
            result.append((i + 1, None, *game.get_values()))
        return result

    def get_dict_repr(self):
        return asdict(self)

    def get_summary(self):
        return {
            'Tournament Name': self.name,
            'Total Points': self.total_points,
            'Played Games': len(self.games),
            'Average Points': self.average_points,
            'Largest Gain': self.max_points,
            'Largest Loss': self.largest_loss,
            'Total Gained Points': self.gained_points,
            'Total Lost Points': self.lost_points,
            'Win Rate': self.get_win_lose(),
            'Placement Frequencies': self.get_placement_frequencies(),
            'Average IPPONs': self.average_ippons,
            'Total IPPONs': self.total_ippons,
            'Average Drones': self.average_drones,
            'Total Drones': self.total_drones,
            'Average KOs': self.average_kos,
            'Total KOs': self.total_kos,
            'Current Points': self.current_points,
            'Points': self.get_points_list,
            'Games': self.games
        }

    def __str__(self):
        result = [f'{self.starting_points}']
        for i, game in enumerate(self.games):
            result.append(f'{i + 1}\t{self.current_points[i + 1]}\t{game}')
        return '\n'.join(result)

    @staticmethod
    def validate_short_name(value, **_) -> str | None:
        if value is None:
            return None
        pattern: str = '^([A-Za-z_][A-Za-z0-9_]*|)$'
        if fullmatch(pattern, value):
            return value
        else:
            raise ValueError(
                'Invalid Short Name: must start with a letter or underscore and only contain letters, numbers, and underscores.')

    def __eq__(self, other):
        return (
                self.name == other.name and
                self.short_name == other.short_name and
                self.starting_points == other.starting_points and
                self.games == other.games
        )

    def __hash__(self):
        return hash((self.name, self.short_name, self.starting_points, tuple(self.games)))
