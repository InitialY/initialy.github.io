from typing import Tuple, List

from openpyxl import Workbook, load_workbook
from tempfile import NamedTemporaryFile

from image_number_extraction import utils
from image_number_extraction.extract.excel_sheet import ExcelSheet
from image_number_extraction.extract.tournament import Tournament


class ExcelWriter:
    """Export stats to an Excel File."""

    _workbook = None
    _append: bool = False
    _excel_file_name: str
    _GAME: str = 'Game'
    _POINTS: str = 'Points'
    _PLACEMENT: str = 'Placement'
    _GAINS: str = 'Gains'
    _DRONES: str = 'Drones'
    _IPPONS: str = 'Ippons'
    _KOS: str = 'KOs'
    _HEADERS: Tuple[str] = (_GAME, _POINTS, _PLACEMENT, _GAINS, _DRONES, _IPPONS, _KOS)

    def __init__(self, excel_file_name: str):
        if self._check_if_excel(excel_file_name):
            self._open_existing_workbook(excel_file_name)
            if not self._append:
                self._workbook = Workbook()
                self._workbook.remove(self._workbook.active)
            self._excel_file_name = excel_file_name

    def _open_existing_workbook(self, workbook_name) -> None:
        if utils.check_file(workbook_name):
            self._workbook = load_workbook(workbook_name)
            self._append = True

    @staticmethod
    def _check_if_excel(workbook_name) -> bool:
        name_parts = workbook_name.split('.')
        file_extention = name_parts[-1]
        return file_extention == 'xlsx'

    def add_tournament(self, tournament: Tournament):
        if tournament is None:
            return
        if tournament.short_name in self._workbook.sheetnames:
            return
        excel_sheet = ExcelSheet(self._workbook, tournament.short_name)

        excel_sheet.add_data([self._HEADERS])
        excel_sheet.add_data(tournament.get_game_values())

        table_len: int = len(tournament.games) + 2  # +2 for the header and empty row
        excel_sheet.create_table(
            table_name=f'{tournament.short_name}_table', min_col=1, max_col=len(self._HEADERS), min_row=1,
            max_row=table_len
        )

        excel_sheet.calculate_current_points_data(
            col=2, min_row=3, max_row=len(tournament.games), gains_header=self._GAINS
        )
        excel_sheet.create_points_chart(tournament.name, table_len)

        aggregate_candidates: List[str] = [self._GAINS, self._DRONES, self._IPPONS, self._KOS]
        aggregate_cols: List[str] = []
        for c in aggregate_candidates:
            i = self._HEADERS.index(c) + 1
            if excel_sheet.has_value_in_col(i, 3, 3 + len(tournament.games)):
                aggregate_cols.append(c)
        excel_sheet.calculate_aggregated_data(
            col_headers=aggregate_cols,
            min_col=3,
            min_row=len(tournament.games) + 3
        )
        excel_sheet.calculate_total_earn(col=3, row=7 + len(tournament.games), gains_header=self._GAINS)
        excel_sheet.calculate_total_lost(col=3, row=8 + len(tournament.games), gains_header=self._GAINS)

        placement_index: int = self._HEADERS.index(self._PLACEMENT) + 1
        has_placement: bool = excel_sheet.has_value_in_col(
            placement_index, min_row=3, max_row=3 + len(tournament.games)
        )
        if has_placement:
            excel_sheet.add_placement_frequency_data(placement_header=self._PLACEMENT)
            excel_sheet.add_win_rate_data(placement_header=self._PLACEMENT)
            excel_sheet.create_placement_frequency_chart(
                c_min_col=10, c_min_row=24, v_min_col=11, v_min_row=23, max_row=31
            )
            excel_sheet.create_win_rate_chart(
                l_min_col=10, l_min_row=40, v_min_col=11, v_min_row=39, max_row=41, dest_cell='M40'
            )
        else:
            excel_sheet.add_win_rate_data_team(self._GAINS)
            excel_sheet.create_win_rate_chart(
                l_min_col=10, l_min_row=24, v_min_col=11, v_min_row=23, max_row=25, dest_cell='M24'
            )

    def close_workbook(self) -> None:
        self._workbook.save(self._excel_file_name)
        self._workbook.close()

    def close_workbook_io(self, bytes_io) -> None:
        self._workbook.save(bytes_io)
