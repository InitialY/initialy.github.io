import os
from typing import Tuple, List

from openpyxl import Workbook, load_workbook

from image_number_extraction.extract.excel_sheet import ExcelSheet
from image_number_extraction.extract.tournament import Tournament


class ExcelWriter:
    """Export stats to an Excel File."""

    workbook = None
    append: bool = False
    excel_file_name: str
    TIME: str = 'Time'
    GAME: str = 'Game'
    POINTS: str = 'Points'
    PLACEMENT: str = 'Placement'
    GAINS: str = 'Gains'
    DRONES: str = 'Drones'
    IPPONS: str = 'Ippons'
    KOS: str = 'KOs'
    HEADERS: Tuple[str] = (TIME, GAME, POINTS, PLACEMENT, GAINS, DRONES, IPPONS, KOS)
    POINTS_EXCEL_COL = HEADERS.index(POINTS) + 1
    GAME_EXCEL_COL = HEADERS.index(GAME) + 1
    PLACEMENT_EXCEL_COL = HEADERS.index(PLACEMENT) + 1
    GAINS_EXCEL_COL = HEADERS.index(GAINS) + 1

    # put these out of view. These are just helpers for coloring the points course
    POS_POINTS_EXCEL_COL = 25
    NEG_POINTS_EXCEL_COL = 26

    FREQUENCY_CATEGORIES_MIN_ROW = 24
    FREQUENCY_VALUES_MIN_ROW = 23
    FREQUENCY_CATEGORIES_COL = len(HEADERS) + 3
    FREQUENCY_VALUES_COL = len(HEADERS) + 4
    FREQUENCY_CATEGORIES: List[str] = ['1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th']

    WIN_RATE_CATEGORIES: List[str] = ['Win', 'Lose']
    WIN_RATE_CATEGORIES_MIN_ROW_SOLO = 40
    WIN_RATE_VALUES_MIN_ROW_SOLO = 39
    WIN_RATE_CATEGORIES_COL = FREQUENCY_CATEGORIES_COL
    WIN_RATE_VALUES_COL = FREQUENCY_VALUES_COL
    WIN_RATE_CATEGORIES_MIN_ROW_TEAM = FREQUENCY_CATEGORIES_MIN_ROW
    WIN_RATE_VALUES_MIN_ROW_TEAM = FREQUENCY_VALUES_MIN_ROW

    def __init__(self, excel_file_name: str):
        if self.__check_if_excel(excel_file_name):
            self.__open_existing_workbook(excel_file_name)
            if not self.append:
                self.workbook = Workbook()
                self.workbook.iso_dates = True
                self.workbook.remove(self.workbook.active)
            self.excel_file_name = excel_file_name

    def __open_existing_workbook(self, workbook_name) -> None:
        if os.path.exists(workbook_name):
            self.workbook = load_workbook(workbook_name)
            self.workbook.iso_dates = True
            self.append = True

    @staticmethod
    def __check_if_excel(workbook_name) -> bool:
        name_parts = workbook_name.split('.')
        file_extension = name_parts[-1]
        return file_extension == 'xlsx'

    def add_tournament(self, tournament: Tournament):
        if tournament is None:
            return
        if tournament.short_name in self.workbook.sheetnames:
            return
        excel_sheet = ExcelSheet(self.workbook, tournament.short_name)

        excel_sheet.set_width_of_time_col()

        excel_sheet.add_data([self.HEADERS])
        excel_sheet.add_data(tournament.get_game_values())

        table_len: int = len(tournament.games) + 2  # +2 for the header and 'starting points' row
        excel_sheet.convert_to_table(
            table_name=f'{tournament.short_name}_table', min_col=1, max_col=len(self.HEADERS), min_row=1,
            max_row=table_len
        )

        excel_sheet.calculate_current_points_data(
            col=self.POINTS_EXCEL_COL, min_row=3, max_row=len(tournament.games), gains_header=self.GAINS
        )

        excel_sheet.separate_points_to_color_chart(
            pos_col=self.POS_POINTS_EXCEL_COL,
            neg_col=self.NEG_POINTS_EXCEL_COL,
            min_row=3,
            max_row=len(tournament.games),
            gains_header=self.GAINS,
            points_header=self.POINTS
        )
        excel_sheet.create_points_chart(
            title=tournament.name,
            x_min_col=self.GAME_EXCEL_COL,
            y1_min_col=self.POS_POINTS_EXCEL_COL,
            y2_min_col=self.NEG_POINTS_EXCEL_COL,
            max_row=table_len,
            tournament_starting_points=tournament.starting_points,
            dest_cell='K3'
        )

        aggregate_candidates: List[str] = [self.GAINS, self.DRONES, self.IPPONS, self.KOS]
        aggregate_cols: List[str] = []
        for c in aggregate_candidates:
            i = self.HEADERS.index(c) + 1
            if excel_sheet.has_value_in_col(col_index=i, min_row=3, max_row=3 + len(tournament.games)):
                aggregate_cols.append(c)

        excel_sheet.calculate_aggregated_data(
            col_headers=aggregate_cols,
            min_col=self.GAINS_EXCEL_COL - 1,
            min_row=len(tournament.games) + 3
        )   # min_col has -1 because caption
        excel_sheet.calculate_total_earn(
            dest_col=self.PLACEMENT_EXCEL_COL,
            dest_row=2 + len(aggregate_candidates)+1 + len(tournament.games),
            gains_header=self.GAINS
        )
        excel_sheet.calculate_total_lost(
            dest_col=self.PLACEMENT_EXCEL_COL,
            dest_row=3 + len(aggregate_candidates)+1 + len(tournament.games),
            gains_header=self.GAINS
        )

        has_placement: bool = excel_sheet.has_value_in_col(
            col_index=self.PLACEMENT_EXCEL_COL, min_row=3, max_row=3 + len(tournament.games)
        )
        if has_placement:
            excel_sheet.add_placement_frequency_data(
                c_min_row=self.FREQUENCY_CATEGORIES_MIN_ROW,
                v_min_row=self.FREQUENCY_VALUES_MIN_ROW,
                c_col=self.FREQUENCY_CATEGORIES_COL,
                v_col=self.FREQUENCY_VALUES_COL,
                frequency_categories=self.FREQUENCY_CATEGORIES,
                placement_col_name=self.PLACEMENT
            )
            excel_sheet.create_placement_frequency_chart(
                c_min_row=self.FREQUENCY_CATEGORIES_MIN_ROW,
                v_min_row=self.FREQUENCY_VALUES_MIN_ROW,
                c_min_col=self.FREQUENCY_CATEGORIES_COL,
                v_min_col=self.FREQUENCY_VALUES_COL,
                max_row=self.FREQUENCY_VALUES_MIN_ROW + len(self.FREQUENCY_CATEGORIES),
                dest_cell='N24'
            )

            excel_sheet.add_win_rate_data(
                c_min_row=self.WIN_RATE_CATEGORIES_MIN_ROW_SOLO,
                v_min_row=self.WIN_RATE_VALUES_MIN_ROW_SOLO,
                c_col=self.WIN_RATE_CATEGORIES_COL,
                v_col=self.WIN_RATE_VALUES_COL,
                win_rate_categories=self.WIN_RATE_CATEGORIES,
                gains_header=self.GAINS
            )
            excel_sheet.create_win_rate_chart(
                l_min_row=self.WIN_RATE_CATEGORIES_MIN_ROW_SOLO,
                v_min_row=self.WIN_RATE_VALUES_MIN_ROW_SOLO,
                l_min_col=self.WIN_RATE_CATEGORIES_COL,
                v_min_col=self.WIN_RATE_VALUES_COL,
                max_row=self.WIN_RATE_VALUES_MIN_ROW_SOLO + len(self.WIN_RATE_CATEGORIES),
                dest_cell='N40'
            )
        else:
            excel_sheet.add_win_rate_data(
                c_min_row=self.WIN_RATE_CATEGORIES_MIN_ROW_TEAM,
                v_min_row=self.WIN_RATE_VALUES_MIN_ROW_TEAM,
                c_col=self.WIN_RATE_CATEGORIES_COL,
                v_col=self.WIN_RATE_VALUES_COL,
                win_rate_categories=self.WIN_RATE_CATEGORIES,
                gains_header=self.GAINS
            )
            excel_sheet.create_win_rate_chart(
                l_min_row=self.FREQUENCY_CATEGORIES_MIN_ROW,
                v_min_row=self.FREQUENCY_VALUES_MIN_ROW,
                l_min_col=self.WIN_RATE_CATEGORIES_COL,
                v_min_col=self.WIN_RATE_VALUES_COL,
                max_row=self.FREQUENCY_VALUES_MIN_ROW + len(self.WIN_RATE_CATEGORIES),
                dest_cell='N24'
            )

    def close_workbook(self) -> None:
        self.workbook.save(self.excel_file_name)
        self.workbook.close()

    def close_workbook_io(self, bytes_io) -> None:
        self.workbook.save(bytes_io)
