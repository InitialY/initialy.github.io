from image_number_extraction.prepare.image_processor import ImageProcessor
from image_number_extraction.extract.extract_config import ExtractConfig


class ExtractConfigFactory:

    def __init__(
            self, points_digit_templates_dir, points_sign_templates_dir, placement_digit_templates_dir,
            stats_digit_templates_dir,
            points_character_mapping, points_sign_mapping, placement_character_mapping, stats_character_mapping,
            points_modifiers, placement_modifiers, stats_modifiers
    ):
        self._init_templates(points_digit_templates_dir, points_sign_templates_dir, placement_digit_templates_dir,
                             stats_digit_templates_dir)
        self._modify_templates(points_modifiers, placement_modifiers, stats_modifiers)
        self._init_mapping(points_character_mapping, points_sign_mapping, placement_character_mapping,
                           stats_character_mapping)

    def _init_templates(self, points_digit_templates_dir, points_sign_templates_dir, placement_digit_templates_dir,
                        stats_digit_templates_dir):
        self.points_digit_templates = ImageProcessor.get_images_of_paths(points_digit_templates_dir)
        self.points_sign_templates = ImageProcessor.get_images_of_paths(points_sign_templates_dir)
        self.placement_digit_templates = ImageProcessor.get_images_of_paths(placement_digit_templates_dir)
        self.stats_digit_templates = ImageProcessor.get_images_of_paths(stats_digit_templates_dir)
        if self._templates_have_none():
            raise ValueError(f"Digit templates in the config have at least one None value.")

    def _templates_have_none(self):
        if any(item is None for item in self.points_digit_templates):
            return True
        if any(item is None for item in self.points_sign_templates):
            return True
        if any(item is None for item in self.placement_digit_templates):
            return True
        if any(item is None for item in self.stats_digit_templates):
            return True
        return False

    def _modify_templates(self, points_modifiers, placement_modifiers, stats_modifiers):
        self.points_digit_templates = \
            [ImageProcessor.modify_image(template, points_modifiers) for template in self.points_digit_templates]
        self.points_sign_templates = \
            [ImageProcessor.modify_image(template, points_modifiers) for template in self.points_sign_templates]
        self.placement_digit_templates = \
            [ImageProcessor.modify_image(template, placement_modifiers) for template in self.placement_digit_templates]
        self.stats_digit_templates = \
            [ImageProcessor.modify_image(template, stats_modifiers) for template in self.stats_digit_templates]

    def _init_mapping(self, points_character_mapping, points_sign_character_mapping, placement_character_mapping,
                      stats_character_mapping):
        self.points_character_mapping = points_character_mapping
        self.points_sign_character_mapping = points_sign_character_mapping
        self.placement_character_mapping = placement_character_mapping
        self.stats_character_mapping = stats_character_mapping
        if self._mapping_is_wrong():
            raise ValueError(f"At least one digit template mapping is wrong. Not enough elements.")

    def _mapping_is_wrong(self):
        if len(self.points_character_mapping) != len(self.points_digit_templates):
            return True
        if len(self.points_sign_character_mapping) != len(self.points_sign_templates):
            return True
        if len(self.placement_character_mapping) != len(self.placement_digit_templates):
            return True
        if len(self.stats_character_mapping) != len(self.stats_digit_templates):
            return True
        else:
            return False

    def get_points_config(self):
        return ExtractConfig(
            digit_templates=self.points_digit_templates,
            template_character_mapping=self.points_character_mapping,
            reset_range=9,
            max_number_of_digits=2
        )

    def get_points_sign_config(self):
        return ExtractConfig(
            digit_templates=self.points_sign_templates,
            template_character_mapping=self.points_sign_character_mapping,
            reset_range=8,
            max_number_of_digits=1
        )

    def get_placements_config(self):
        return ExtractConfig(
            digit_templates=self.placement_digit_templates,
            template_character_mapping=self.placement_character_mapping,
            matching_threshold=.1,
            reset_range=99,
            start_index=1,
            max_number_of_digits=1
        )

    def get_stats_config(self):
        return ExtractConfig(
            digit_templates=self.stats_digit_templates,
            template_character_mapping=self.stats_character_mapping,
            matching_threshold=0.9,
            reset_range=13,
            max_number_of_digits=2
        )
