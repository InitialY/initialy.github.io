from typing import Callable, List, TypeAlias
from cv2.typing import MatLike

import image_number_extraction.prepare.image_processor as ipro
from image_number_extraction.extract.extract_config import ExtractConfig

CV2Image: TypeAlias = MatLike | None


class ExtractConfigFactory:

    def __init__(
            self,
            points_digit_templates_dir: str,
            points_sign_templates_dir: str,
            placement_digit_templates_dir: str,
            stats_digit_templates_dir: str,
            points_character_mapping: List[str],
            points_sign_mapping: List[str],
            placement_character_mapping: List[str],
            stats_character_mapping: List[str],
            points_modifiers: List[Callable],
            placement_modifiers: List[Callable],
            stats_modifiers: List[Callable]
    ):
        self.__init_templates(
            points_digit_templates_dir, points_sign_templates_dir, placement_digit_templates_dir,
            stats_digit_templates_dir
        )
        self.__modify_templates(
            points_modifiers, placement_modifiers, stats_modifiers
        )
        self.__init_mapping(
            points_character_mapping, points_sign_mapping, placement_character_mapping, stats_character_mapping
        )

    def __init_templates(
            self,
            points_digit_templates_dir: str,
            points_sign_templates_dir: str,
            placement_digit_templates_dir: str,
            stats_digit_templates_dir: str
    ):
        self.points_digit_templates: List[CV2Image] = ipro.get_images_of_paths(points_digit_templates_dir)
        self.points_sign_templates: List[CV2Image] = ipro.get_images_of_paths(points_sign_templates_dir)
        self.placement_digit_templates: List[CV2Image] = ipro.get_images_of_paths(placement_digit_templates_dir)
        self.stats_digit_templates: List[CV2Image] = ipro.get_images_of_paths(stats_digit_templates_dir)
        if self.__templates_have_none():
            raise ValueError(f"Digit templates in the config have at least one None value.")

    def __templates_have_none(self):
        if any(item is None for item in self.points_digit_templates):
            return True
        if any(item is None for item in self.points_sign_templates):
            return True
        if any(item is None for item in self.placement_digit_templates):
            return True
        if any(item is None for item in self.stats_digit_templates):
            return True
        return False

    def __modify_templates(
            self,
            points_modifiers: List[Callable],
            placement_modifiers: List[Callable],
            stats_modifiers: List[Callable]
    ):
        self.points_digit_templates: List[CV2Image] = \
            [ipro.modify_image(template, points_modifiers) for template in self.points_digit_templates]
        self.points_sign_templates: List[CV2Image] = \
            [ipro.modify_image(template, points_modifiers) for template in self.points_sign_templates]
        self.placement_digit_templates: List[CV2Image] = \
            [ipro.modify_image(template, placement_modifiers) for template in self.placement_digit_templates]
        self.stats_digit_templates: List[CV2Image] = \
            [ipro.modify_image(template, stats_modifiers) for template in self.stats_digit_templates]

    def __init_mapping(
            self,
            points_character_mapping: List[str],
            points_sign_character_mapping: List[str],
            placement_character_mapping: List[str],
            stats_character_mapping: List[str]
    ):
        self.points_character_mapping = points_character_mapping
        self.points_sign_character_mapping = points_sign_character_mapping
        self.placement_character_mapping = placement_character_mapping
        self.stats_character_mapping = stats_character_mapping
        if self.__mapping_is_wrong():
            raise ValueError(f"At least one digit template mapping is wrong. Not enough elements.")

    def __mapping_is_wrong(self):
        mappings = [
            (self.points_character_mapping, self.points_digit_templates),
            (self.points_sign_character_mapping, self.points_sign_templates),
            (self.placement_character_mapping, self.placement_digit_templates),
            (self.stats_character_mapping, self.stats_digit_templates)
        ]
        return any(len(mapping) != len(template) for mapping, template in mappings)

    def get_points_config(self):
        return ExtractConfig(
            digit_templates=self.points_digit_templates,
            template_character_mapping=self.points_character_mapping,
            reset_range=9,
            max_number_of_digits=2
        )

    def get_points_sign_config(self):
        return ExtractConfig(
            digit_templates=self.points_sign_templates,
            template_character_mapping=self.points_sign_character_mapping,
            reset_range=8,
            max_number_of_digits=1
        )

    def get_placements_config(self):
        return ExtractConfig(
            digit_templates=self.placement_digit_templates,
            template_character_mapping=self.placement_character_mapping,
            matching_threshold=.1,
            reset_range=99,
            start_index=1,
            max_number_of_digits=1
        )

    def get_stats_config(self):
        return ExtractConfig(
            digit_templates=self.stats_digit_templates,
            template_character_mapping=self.stats_character_mapping,
            matching_threshold=0.9,
            reset_range=13,
            max_number_of_digits=2
        )
